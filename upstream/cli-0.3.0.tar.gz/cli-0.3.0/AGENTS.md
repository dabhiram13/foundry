# Shared Rules — every agent reads this

Supabase project: `YOUR_SUPABASE_PROJECT_REF`

## Tech Stack

- Next.js 16 (App Router, RSC by default, proxy.ts is the MIDDLEWARE)
- React 19 (server components first, use client on lowest leaf)
- Supabase (auth with getClaims(), DB, RLS, realtime)
- oRPC (type-safe procedures with ZOD)
- Stripe (using SUPABASE EDGE FUNCTIONS supabase directly)
- Tailwind v4
- shadcn/ui (NEVER use --overwrite — custom styling will be destroyed)

## Code Standards

- Server components by default
- No useEffect for data fetching
- Caching: use cache + cacheLife + cacheTag
- RLS on every table, no service role in client code
- Type-safe end-to-end (DB -> oRPC -> React)
- No `any`, no `@ts-ignore`, no `as unknown as X`
- Judgment — scope, evidence, async-state, trust-boundaries, entitlement, data-flow, visual — lives in `.claude/philosophy/`: injected per agent, cited in briefs, graded by evaluators. Linked here, never restated.

## shadcn/ui Rules

- NEVER use `--overwrite` when installing shadcn components
- When `npx shadcn@latest add` prompts to overwrite, always decline (N)
- If a new component depends on an existing one, install only new files

## Quality Gates

| Gate | Command | Must pass |
|------|---------|-----------|
| Types | `npx tsc --noEmit` | Zero errors |
| Lint | `npx eslint .` | Zero errors |
| Patterns | `bash scripts/lint-patterns.sh webapp/` | Zero FAIL |
| Build | `npm run build` | Clean build |
| All of the above | `bash scripts/verify.sh --all` | `VERIFY: PASS` |

`verify.sh` is one script in three homes: `.githooks/pre-commit` (`--staged`), CI (`.github/workflows/verify.yml`, `--all`), and the Claude Stop hook during a build (`--changed`). A check that cannot run is a FAIL, not a skip. Patterns (line-level) and lint (file-level) are a ratchet: what you touch must be clean; pre-existing findings are reported as debt (`.claude/state/verify-debt.txt`), not blocking. typecheck, tests and build are whole-tree.

## Workspace

- Active work: `dev/active/{feature}/`
- Completed: `dev/archive/{feature}/`
- Agent plans: `dev/active/{feature}/plan.md`
- Agent decisions: `dev/active/{feature}/decisions.md`
- Never modify archived features

## Agent Workspace Protocol

When working on a feature:
1. Read `dev/active/{feature}/plan.md` (your section)
2. Read ONLY files listed in your Reference Manifest
3. Append decisions to `dev/active/{feature}/decisions.md`
4. Do not modify files outside your scope
5. Log deviations from plan.md in decisions.md under `## Deviations`

## Docs

- Master index: `docs/INDEX.md`
- Project docs: `docs/project/` (7 files — only for deep new-project discovery)
- Tool docs: `docs/tools/` (stack docs + per-idea tool docs when discovery actually runs)

## Where Things Live

| Path | What |
|------|------|
| `.claude/philosophy/` | Seven judgment docs — goal · reasoning · priority · examples · evidence. Each agent's `philosophy:` list names what it loads |
| `docs/project/` | 7 files: product overview, users & journeys, feature map, brand, tech reqs, external tools, UX patterns |
| `docs/tools/` | Stack docs (Inngest, catalog) + per-idea tool docs only when discovery runs |
| `docs/supabase/` | Supabase reference (auth, RLS, realtime, security, views) |
| `docs/orpc/` | oRPC reference (procedures, schemas, client, middleware) |
| `docs/stripe/` | Stripe reference (database, API, frontend, edge functions) |
| `docs/built/` | Built feature references (auth, billing, design-system, etc.) |
| `dev/active/{name}/` | In-progress work (plan, decisions, context) |
| `dev/archive/{name}/` | Completed features |
| `db-schema.md` | Tables, columns, RLS, relationships |

## Per-harness

- Claude Code reads `CLAUDE.md` and `.claude/` — the source of truth for every harness.
- Codex reads this file plus `.codex/agents/*.toml`, `.codex/hooks.json`, `.codex/config.toml` and `.agents/skills/` — all generated, never edited by hand; `.agents/PORTING.md` says what maps to what.
- After any `.claude/` edit: `bash scripts/gen-agents.sh` (`--check` fails the build on drift).
