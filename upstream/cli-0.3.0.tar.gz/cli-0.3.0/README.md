# buildthisnow

**The Claude Code framework for Next.js + Supabase SaaS.**

One `npx` install drops in 60 skills, 34 slash commands, and a specialist agent team that builds, audits, secures, monitors, and heals your app — from first commit to production and everything after.

Counted by the rule in `dev/active/harness-v2/phases/phase-8-skills.md`: 60 top-level `SKILL.md` files under `.claude/skills/` (85 including the `references/` copies routers load on demand). By content lines, and classified by `skills-lock.json`: 46,800 owned / 30,849 vendored (60.3% owned) across 77,649 lines.

```bash
npx buildthisnow login <YOUR-LICENSE-KEY>   # once per machine
npx buildthisnow init                       # once per project
```

buildthisnow is licensed. `login`, `init`, `update` and the plugin itself validate your key
against the licence server; the harness arrives as a signed payload — see
[How the install works](#how-the-install-works).

Built by [@speedy_devv](https://www.instagram.com/speedy_devv/) — part of the **Build Kit** series. Follow for tutorials, walkthroughs, and new kit drops.

[![Instagram](https://img.shields.io/badge/Follow%20%40speedy__devv-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/speedy_devv/)

---

## Why vertical, not horizontal?

Most Claude Code frameworks ship for everyone. This one ships for one stack and does it best-in-class:

- **Web:** Next.js 16 · React 19 · oRPC · Supabase · Stripe · Tailwind v4 · shadcn/ui · Inngest · Sentry

If you're building something else, pick a different framework. If you're building this — no one else comes close on depth.

---

## What Is This?

Most starter kits give you boilerplate. This one gives you a **full AI development team**.

Build Kit Template is a production-ready SaaS skeleton with specialist agents that don't just build your app — they stick around to maintain it, secure it, and improve it.

### What the agents build for you

- **Auth** — email + password with OTP verification, Google OAuth, JWT claims, session cookies
- **Billing** — Stripe checkout, one-time purchases or subscriptions, pricing pages, customer portal
- **Onboarding** — multi-step flow, preference system, auth-time gating
- **Design System** — OKLCH color tokens, gradient buttons, shadow system, dark mode, full shadcn/ui
- **Landing Page** — marketing page with sticky scroll, copy framework, responsive
- **Legal** — terms of service, privacy policy, consent flows

### What the agents do after you ship

This is where Build Kit is different. The agents don't disappear after the build. They keep working:

- **Security audits** — RLS gap detection, injection scanning, auth bypass checks, data leakage analysis
- **Penetration testing** — real exploit validation against your running app, not just static analysis
- **Performance audits** — frontend and backend profiling, Postgres query optimization, caching review
- **Dependency audits** — outdated packages, unused dependencies, dead code detection
- **Error monitoring** — Sentry integration, deep triage, root cause analysis, auto-fix recommendations
- **Pattern drift detection** — catches inconsistencies across features before they compound
- **Self-healing** — reads all reports, creates a branch, fixes critical issues, runs quality gates, verifies the fix, and emails you the verdict
- **Scheduled monitoring** — set up recurring security, performance, and error checks that run on autopilot

One command to pentest. One command to heal. One command to audit everything. The agents handle it.

## Tech Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 16 (App Router, React Server Components) |
| UI | React 19 + Tailwind v4 + shadcn/ui |
| Backend | Supabase (auth, DB, RLS, realtime) + oRPC (type-safe API) |
| Payments | Stripe (via Supabase Edge Functions) |
| Background Jobs | Inngest |

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) 18+
- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) CLI installed
- A buildthisnow licence key — [buildthisnow.com](https://www.buildthisnow.com)
- A Supabase account
- A Stripe account (for billing features)

### 1. Install Claude Code

```bash
npm install -g @anthropic-ai/claude-code
```

### 2. Install into your project and open it

```bash
npx buildthisnow login <YOUR-LICENSE-KEY>   # once per machine: validates, caches at 0600
cd <your-project>                           # a new or existing Next.js 16 repo
npx buildthisnow init                       # project-side files + .claude/settings.json
claude                                      # accept the codekit plugin when Claude Code asks
```

That is the whole install. `init` defaults to **plugin mode**: the harness — 28 agents, 34
commands, 60 skills, the hooks, the philosophy docs — arrives as the `codekit` Claude Code plugin,
fetched once into `~/.buildthisnow/plugin/` and shared by every project on the machine. `init`
writes only what a plugin cannot carry: `.agents/`, `.codex/`, `docs/`, `.githooks/`,
`scripts/verify.sh` and friends, plus a `.claude/settings.json` that holds your permissions and
registers the plugin. Using Codex as well? Run `npx buildthisnow init --copy` instead —
`.codex/hooks.json` runs the scripts in `.claude/hooks/`, which only a copy install puts on disk.

On first launch Claude Code asks to run `npx -y buildthisnow@latest plugin-path`. **That command is
the licence check** — accept it. If you are not prompted, add it by hand:

```bash
claude plugin marketplace add https://www.buildthisnow.com/plugin/marketplace.json
claude plugin install codekit@codekit
```

Claude Code re-runs `plugin-path` on every install, on every update, and once per session in the
background — so a new release reaches you without you asking: it offers `/reload-plugins`. A key can
also come from `BUILDTHISNOW_KEY` in your environment; `login` prompts if it finds neither.

**Commands are namespaced** as a plugin: `/codekit:start`, `/codekit:spec`, `/codekit:security`.
The bare `/start` this README writes still works as long as nothing else claims that name.

```bash
npx buildthisnow license        # what key this machine is using, and its status
npx buildthisnow update         # refresh the project-side files, diffing your edits
npx buildthisnow doctor         # check the install
npx buildthisnow logout         # release this machine's seat and clear the cache
```

#### Or vendor the whole harness in your repo — `--copy`

```bash
npx buildthisnow init --copy
```

The 0.2.x layout, unchanged: the entire payload including `.claude/` is copied into your project,
commands are bare (`/start`), and `npx buildthisnow update` diffs the whole tree against your edits.
Pick this if you want the harness under version control with your app. Already on it? Nothing is
forced — `update` keeps working, and `npx buildthisnow update --to-plugin` migrates when you want
it to (it lists the unmodified harness files it would delete, keeps everything you edited, and asks
before touching anything).

#### Or run it from a clone — the dev route

```bash
git clone https://github.com/ZeiProX76/codekit && cd codekit
claude --plugin-dir ./.claude
```

No licence, no install, no copy: `.claude/` is itself a valid plugin root. This is how the harness
is developed.

Read [docs/LICENSING.md](docs/LICENSING.md) for the full comparison. One thing to know whichever
route you pick:

- **A plugin cannot ship permissions, and `npx buildthisnow init` is what fills the gap.** A
  plugin's own settings honour only `agent` and `subagentStatusLine`, so `init` writes the
  permissions into your project's `.claude/settings.json` itself — the `allow` list plus eight
  `deny` entries: `git rebase`, `git reset --hard`, `git push --force`, `git push -f`,
  `git filter-branch`, `git filter-repo`, `git reflog expire`, `npx shadcn@latest … --overwrite`.
  `init` also sets `core.hooksPath` for the pre-commit gate and leaves `/start` to compose your
  `CLAUDE.md`. Belt and braces: `.claude/hooks/guardrails.sh`
  is a `PreToolUse` hook that denies the same eight shapes and ships **inside** the plugin, so the
  guardrail is there even on a bare `claude plugin install` with no `init`.

### 3. Start here once — `/start`

```
/start
```

`/start` is the initial intake entrypoint.

- **Existing project + small fix** → inspect narrowly, spec it, solve it fast
- **New project + simple build** → write a starter plan, then spec and build
- **Existing project + complex** → run a bounded repo scan first
- **New project + complex** → route into deep discovery only when it is actually needed

You should not need to decide between internal commands before the kit gives you something useful.
Once `/start` has routed the project, later work should go through the recommended next command directly. Do not keep re-running `/start` unless you want to reframe the project.

### 4. Continue with the recommended next step

```
/spec        # focused feature or fix after `/start`
/discover    # only for new + complex work
/setup       # after discovery, or whenever service wiring / credentials are the blocker
/payments    # choose Stripe, Lemon Squeezy, or Polar and verify the billing flow
/deploy      # choose the shipping path and deploy safely
/mvp-spec    # only when you want the roadmap
/mvp-build   # build the next roadmap item
```

`/start` should make the next action obvious. After intake, the downstream commands are the workflow.

## The Full Command Arsenal

### Build

| Command | What it does |
|---------|-------------|
| `/start` | One-time intake — classifies the request, proposes one path, and gets to a useful artifact fast |
| `/discover` | Deep discovery for new + complex product work only |
| `/setup` | Guided environment and credential setup after discovery or when service wiring blocks progress |
| `/payments` | Route billing work across Stripe, Lemon Squeezy, and Polar with a verification path |
| `/deploy` | Choose the right deploy path and activate the right shipping skills |
| `/mvp-spec` | Generate specs for all MVP features |
| `/mvp-build` | Build the next feature from your roadmap |
| `/spec` | Spec + build any new feature on demand |
| `/enhance` | Improve an existing feature |

### Protect

| Command | What it does |
|---------|-------------|
| `/security` | 5 agents scan for RLS gaps, injection, auth bypass, data leakage, config issues |
| `/pentest` | API + browser pentesting against your running app |
| `/audit` | Dependency, dead code, and code health check |

### Maintain

| Command | What it does |
|---------|-------------|
| `/monitor` | Schedule recurring security, performance, and error checks |
| `/sentry` | Deep triage of production errors with fix recommendations |
| `/performance` | Frontend + backend + database performance audit |
| `/drift` | Catch pattern inconsistencies across features |
| `/heal` | Auto-fix critical issues, run quality gates, verify, and report |

### Design

| Command | What it does |
|---------|-------------|
| `/design` | Brand design system tuner |
| `/logo` | Generate 6 brand logo variations |
| `/landing-design` | Landing page design competition between agents |

## How the install works

The npm package is the CLI, not the harness. `npm pack` contains `bin/`, `lib/`,
`scripts/`, `AGENTS.md`, `LICENSE.md` and `README.md` — about 20 files. The
skills, agents, commands and docs arrive separately. What `npx buildthisnow init`
does, in order:

1. **Validate.** It resolves your key (`--key` → `BUILDTHISNOW_KEY` → the cache
   → an interactive prompt) and POSTs it with a machine fingerprint to the
   licence server. The result is cached in `~/.buildthisnow/config.json` at mode
   `0600`, re-checked once a day, and honoured offline in between. `npx
   buildthisnow login` is just this step on its own.
2. **Fetch, once per machine.** It asks for a signed download URL, streams the
   payload to a temp file, and hashes it. A sha256 that does not match the
   server's value aborts — a payload is never extracted on a mismatch. The
   verified payload is extracted to `~/.buildthisnow/plugin/<version>/`, with a
   `current.json` pointer beside it. If that version is already there, nothing
   is downloaded.
3. **Copy the project-side files.** `.agents/`, `.codex/`, `docs/` and
   `.githooks/` are copied into your project, along with `scripts/verify.sh`,
   `scripts/lint-patterns.sh`, `scripts/security-scan-staged.sh`,
   `scripts/send-report-email.sh`, `.github/workflows/verify.yml`, `AGENTS.md`,
   `db-schema.md` and `skills-lock.json`. `.claude/` is **not** copied — that is
   the plugin. (`init --copy` copies it too, and nothing else changes.) Existing
   files that differ stop the install unless you pass `--force`.
4. **Compose `.claude/settings.json`.** The payload's settings minus its `hooks`
   block (the plugin carries the hooks), plus `enabledPlugins:
   {"codekit@codekit": true}` and `extraKnownMarketplaces` pointing at the raw
   marketplace manifest — so Claude Code finds and enables the plugin with no
   manual command. An existing settings.json is merged, not replaced: the
   `allow`/`deny` arrays are unioned and every other key you set is left alone.
5. **Record.** `.claude/state/install.json` records the mode (`plugin` or
   `copy`), the CLI version, payload version and payload hash; the payload's
   per-file sha256 manifest is snapshotted to `.claude/state/manifest.json` so
   `update` can tell your edits from ours. Your `CLAUDE.md` is not touched —
   `/start` composes it on the first session.
6. **Wire the git hook.** `git config core.hooksPath .githooks`, so
   `scripts/verify.sh --staged` runs at pre-commit. Only a `git config` call can
   do this, which is one of the two reasons `init` exists alongside the plugin.

Then, inside Claude Code, the marketplace entry's `command` source runs
`npx -y buildthisnow@latest plugin-path`: it re-checks the licence, refreshes
`~/.buildthisnow/plugin/` when the server reports a new version, and prints one
absolute path for Claude Code to copy. It runs on install, on update, once per
session in the background, and whenever the enabled version is missing from the
cache — a non-zero exit (no licence, expired, suspended) fails the install. A
licence that lapses later stops *updates*; the plugin Claude Code already copied
stays at its installed version, and `.claude/hooks/license-notice.sh` says so in
one line at session start.

`npx buildthisnow update` re-fetches and compares every file three ways: against
the new payload, against the manifest from your last install, and against what is
on disk. Files you never touched are refreshed silently; files you edited prompt
you per file with a diff. In plugin mode it diffs only the project-side trees —
the harness itself updates through the plugin. Managed files that live in
directories you own — `scripts/`, `.github/workflows/` and the project root — are
kept as-is when they differ, and only replaced if you pass `--force`. Nothing
under `.claude/state/`, `.claude/observations/`, `.claude/settings.local.json` or
the other protected paths is ever read, hashed, shipped, or overwritten.

## Project Structure

```
.claude/
  commands/         # slash commands
  agents/           # specialist agents
  skills/           # curated skills (patterns, best practices)
  docs/             # slim pattern guides the orchestrator can load fast
  workflows/        # 6 skeleton feature workflows
  hooks/            # session + agent hooks; orchestrator-init.sh injects the playbook
  philosophy/       # seven judgment docs (goal · reasoning · priority · examples · evidence), injected per agent
  settings.json     # permissions + plugin registration; hook registrations only in --copy installs
  hooks/hooks.json  # the same hooks with ${CLAUDE_PLUGIN_ROOT} paths — the plugin route
  .claude-plugin/plugin.json   # plugin manifest; .claude/ IS the plugin root

.claude-plugin/
  marketplace.json  # this repo is its own single-plugin marketplace

.codex/             # GENERATED from .claude/ — agents as TOML, hooks.json, config.toml; what Codex reads
.agents/            # GENERATED from .claude/ — do not edit; see .agents/PORTING.md
                    # the Codex / Copilot subset, plus a hand-owned Codex-only remainder

AGENTS.md           # the shared rules every harness reads; CLAUDE.md imports it with @AGENTS.md
CLAUDE.md           # Claude-only additions on top of that import — nothing else

docs/
  project/          # Your product docs (generated only when deep discovery is needed)
  built/            # Feature references (generated at build time)
  patterns/         # Frontend + backend + quality patterns
  supabase/         # Supabase reference docs
  orpc/             # oRPC reference docs
  stripe/           # Stripe reference docs
  tools/            # Inngest + tool catalog + per-idea docs

.githooks/
  pre-commit        # security scan + verify.sh --staged

.github/
  workflows/
    verify.yml      # verify.sh --all in CI

scripts/
  verify.sh              # the one check: malware-scan · harness-sync · patterns · typecheck · lint · tests · build — run by pre-commit, CI and the Stop hook
  lint-patterns.sh       # the objective rules as greps, cited by rule id
  security-scan-staged.sh# pre-commit secret + config scan
  build-manifest.js      # release: sha256 every payload file into .claude/.manifest.json
  release-payload.sh     # release: build and upload the payload tarball (--dry-run first)
  gen-agents.sh          # regenerate .agents/ from .claude/; --check fails the build on drift
  agent.sh               # run one agent under AGENT_HARNESS=claude|codex|print — the one seam
  eval-cross-harness.sh  # the same exam under each harness, one row per pair (not yet run)

bin/ lib/           # the CLI itself — the only thing npm ships
webapp/             # Next.js 16 app — cloned by `/skeleton saas`, not in the npm package
supabase/           # Migrations + edge functions — cloned by `/skeleton saas`
```

## Environment Variables

See `webapp/.env.example` for all required keys. Environment and account wiring should happen inside the relevant build flow, not through a separate default setup entrypoint.

---

## Follow @speedy_devv

This template is part of the Build Kit ecosystem — starter kits that ship with their own AI dev team. Follow for updates, new kits, tutorials, and build-in-public content:

**Instagram** — [instagram.com/speedy_devv](https://www.instagram.com/speedy_devv/)

---

## License

MIT — see [LICENSE.md](./LICENSE.md).
