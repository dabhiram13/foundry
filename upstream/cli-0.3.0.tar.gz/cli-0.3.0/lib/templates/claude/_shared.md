# {{PRODUCT_NAME}} — CLAUDE.md
<!-- Surface: {{SURFACE}}. Managed by buildthisnow. Your rules go BELOW the END marker. -->

The shared rules — stack, standards, quality gates, workspace protocol — live in `AGENTS.md`,
which every agent harness reads. Claude Code imports it here. **Edit `AGENTS.md`, never this
file's rules.**

@AGENTS.md

## Behavior
1. Think first — state assumptions, ask on ambiguity, don't pick silently.
2. Simplest code that works — no speculative abstractions, no unrequested error handling.
3. Surgical edits — every changed line traces to the request; don't "improve" adjacent code.
4. Goal-driven — define success ("write a failing test, make it pass"), verify, loop.

## Claude-only
- `.claude/docs/` — slim orchestrator-facing pattern guides (backend, frontend, UI).
- `.claude/philosophy/` — judgment docs. An agent's `philosophy:` frontmatter names what it loads;
  `.claude/hooks/subagent-prime.sh` injects them at SubagentStart.
- The orchestrator playbook is not a file you read — `.claude/hooks/orchestrator-init.sh` injects it
  at SessionStart.
- `.claude/settings.json` carries the permission `deny` list and the hook registrations.
- Refs: `docs/INDEX.md` · `.claude/docs/` · `db-schema.md`

## Self-learn
When a non-obvious lesson emerges (a gotcha, a rule a future session must not relearn), say so and
propose where it belongs: a mechanical rule goes to `scripts/lint-patterns.sh`, a judgment call to
`.claude/philosophy/`. Propose; the human accepts. Nothing rewrites those files unattended.
