#!/usr/bin/env bash
# agent.sh — run one codekit agent under whichever harness is installed.
#
# The only captive piece of this harness is spawning. State already lives in
# files (dev/active/<feature>/…), so the script path and the in-session path
# cannot disagree about what is done. This is the one place a harness is named.
#
# Usage:
#   scripts/agent.sh <agent> --prompt "<task>"        [--feature <name>] [--dry-run]
#   scripts/agent.sh <agent> --prompt-file <path>     [--feature <name>] [--dry-run]
#   scripts/agent.sh <agent> -                        (task on stdin)
#
#   AGENT_HARNESS=claude|codex|print   default: claude if installed, else codex,
#                                      else print. `print` writes the assembled
#                                      brief to stdout and exits 0 — no API spend,
#                                      which is what the eval and the tests use.
#
# It runs exactly ONE agent. Fan-out is the caller's decision: run N invocations
# concurrently if the caller can, sequentially if it cannot.
#
# The brief is assembled by .claude/hooks/subagent-prime.sh — the same code the
# SubagentStart hook runs — so the script path and the hook path cannot drift.
# The agent body (frontmatter stripped) is prepended; Claude Code loads that part
# natively from .claude/agents/<name>.md, nothing else does.
#
# Flags: the `codex exec` flags below were verified against `codex --help` on
# codex-cli 0.149.1. The `claude -p` flags are still UNVERIFIED — they were not
# executed while writing this (no credentials, no spend).
# Run with --dry-run first; it prints the exact argv without running it.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
HARNESS_ROOT="${CLAUDE_PLUGIN_ROOT:-$ROOT/.claude}"

AGENT=""
TASK=""
FEATURE=""
DRY=0

usage() { sed -n '2,29p' "$0"; exit "${1:-0}"; }

[ $# -gt 0 ] || usage 2
AGENT="$1"; shift
case "$AGENT" in -h|--help) usage 0 ;; esac

while [ $# -gt 0 ]; do
  case "$1" in
    --prompt)      TASK="${2:?--prompt needs text}"; shift 2 ;;
    --prompt-file) TASK="$(cat "${2:?--prompt-file needs a path}")"; shift 2 ;;
    -)             TASK="$(cat)"; shift ;;
    --feature)     FEATURE="${2:?--feature needs a name}"; shift 2 ;;
    --dry-run)     DRY=1; shift ;;
    -h|--help)     usage 0 ;;
    *) echo "agent.sh: unknown argument: $1" >&2; usage 2 ;;
  esac
done

AGENT_FILE="$HARNESS_ROOT/agents/$AGENT.md"
[ -f "$AGENT_FILE" ] || { echo "agent.sh: no such agent: $AGENT ($AGENT_FILE)" >&2; exit 1; }
[ -n "$TASK" ] || { echo "agent.sh: no task — pass --prompt, --prompt-file or -" >&2; exit 2; }

# ── Frontmatter: read the fields the adapters need, strip the block from the body ──
fm() { sed -n '2,/^---$/p' "$AGENT_FILE" | sed -n "s/^$1: *//p" | head -1; }
MODEL="$(fm model || true)"
TOOLS="$(fm tools || true)"
BODY="$(awk 'NR==1 && $0=="---" {fm=1; next} fm && $0=="---" {fm=0; next} !fm' "$AGENT_FILE")"

# ── The brief: the same philosophy + skills the SubagentStart hook injects ──
PRIMED=""
if [ -x "$HARNESS_ROOT/hooks/subagent-prime.sh" ] || [ -f "$HARNESS_ROOT/hooks/subagent-prime.sh" ]; then
  PRIMED="$(printf '{"agent_type":"%s"}' "$AGENT" \
    | CLAUDE_PROJECT_DIR="$ROOT" bash "$HARNESS_ROOT/hooks/subagent-prime.sh" 2>/dev/null \
    | (jq -r '.hookSpecificOutput.additionalContext // empty' 2>/dev/null || true))"
fi

BRIEF="$BODY"
if [ -n "$PRIMED" ]; then
  BRIEF="$BRIEF

$PRIMED"
fi
if [ -n "$FEATURE" ]; then
  BRIEF="$BRIEF

## Feature
Work in \`dev/active/$FEATURE/\`. Read plan.md, append to decisions.md. Do not modify files outside your scope."
fi

# ── Harness selection ──
HARNESS="${AGENT_HARNESS:-}"
if [ -z "$HARNESS" ]; then
  if command -v claude >/dev/null 2>&1; then HARNESS=claude
  elif command -v codex >/dev/null 2>&1; then HARNESS=codex
  else HARNESS=print
  fi
fi

# ── Adapters. One function each; this is the whole harness-specific surface. ──
run_claude() {
  set -- claude -p "$TASK" --append-system-prompt "$BRIEF" --output-format json
  if [ -n "$TOOLS" ]; then set -- "$@" --allowed-tools "$TOOLS"; fi
  if [ -n "$MODEL" ]; then set -- "$@" --model "$MODEL"; fi
  if [ "$DRY" = "1" ]; then printf '%q ' "$@"; echo; return 0; fi
  "$@"
}

run_codex() {
  # codex exec takes the task as its argument; the brief goes in as instructions.
  # -s workspace-write matches the sandbox the generated .codex/agents/*.toml ask
  # for; --skip-git-repo-check lets it run from a worktree or an unversioned copy;
  # --output-last-message is the only way to get the final answer on its own,
  # separate from the streamed transcript.
  local msg tmp status
  msg="$BRIEF

---

$TASK"
  if [ "$DRY" = "1" ]; then
    printf 'codex exec -s workspace-write --skip-git-repo-check --output-last-message <tmp> <brief+task, %s bytes>\n' "${#msg}"
    return 0
  fi
  tmp="$(mktemp "${TMPDIR:-/tmp}/agent-codex.XXXXXX")"
  status=0
  codex exec -s workspace-write --skip-git-repo-check --output-last-message "$tmp" "$msg" || status=$?
  if [ -s "$tmp" ]; then cat "$tmp"; fi
  rm -f "$tmp"
  return "$status"
}

run_print() {
  printf '%s\n\n---\n\n%s\n' "$BRIEF" "$TASK"
}

case "$HARNESS" in
  claude) run_claude ;;
  codex)  run_codex ;;
  print)  run_print ;;
  *) echo "agent.sh: unknown AGENT_HARNESS: $HARNESS (claude|codex|print)" >&2; exit 2 ;;
esac
