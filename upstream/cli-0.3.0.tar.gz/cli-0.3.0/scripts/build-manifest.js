#!/usr/bin/env node
'use strict';

// build-manifest.js — write the payload manifest the CLI diffs against.
//
// Walks MANAGED_TREES + MANAGED_FILES from the repo root, sha256s every file,
// and writes .claude/.manifest.json:
//
//   { "version": "0.2.2", "generated_at": "…Z", "files": { "<relpath>": "<sha256>" } }
//
// lib/manifest.js reads this file out of the extracted payload; lib/diff.js
// classifies each entry against the user's disk and the manifest snapshotted at
// their last install. A payload without it makes `update` abort (update.js:62).
//
// Anything matching PROTECTED_PATTERNS is skipped — those paths are local state
// and must never be hashed, shipped, or overwritten. Python bytecode and macOS
// directory metadata are skipped for the same reason: they are build output, not
// harness content.
//
// Node only. No dependencies, no network. Run from the repo root:
//
//   node scripts/build-manifest.js            # write .claude/.manifest.json
//   node scripts/build-manifest.js --dry-run  # print what it would hash
//
// scripts/release-payload.sh runs this before it tars.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const {
  VERSION,
  MANAGED_TREES,
  MANAGED_FILES,
  PROTECTED_PATTERNS,
} = require('../lib/constants');

const MANIFEST_REL = '.claude/.manifest.json';

// Build output that is never harness content, wherever it appears.
const SKIP_NAMES = new Set(['__pycache__', '.DS_Store', 'node_modules', '.git']);
const SKIP_SUFFIXES = ['.pyc', '.pyo', '.swp'];

function isProtected(rel) {
  return PROTECTED_PATTERNS.some((p) => rel === p || rel.startsWith(p));
}

function isSkipped(rel) {
  const base = path.posix.basename(rel);
  if (SKIP_NAMES.has(base)) return true;
  if (SKIP_SUFFIXES.some((s) => base.endsWith(s))) return true;
  return rel === MANIFEST_REL;
}

function sha256File(abs) {
  return crypto.createHash('sha256').update(fs.readFileSync(abs)).digest('hex');
}

// Depth-first walk yielding repo-relative POSIX paths for regular files only.
function walk(root, rel, out) {
  const abs = path.join(root, rel);
  let entries;
  try {
    entries = fs.readdirSync(abs, { withFileTypes: true });
  } catch (err) {
    if (err.code === 'ENOENT') return out;
    throw err;
  }
  for (const entry of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
    const childRel = rel ? `${rel}/${entry.name}` : entry.name;
    if (SKIP_NAMES.has(entry.name)) continue;
    if (isProtected(childRel) || isProtected(`${childRel}/`)) continue;
    if (entry.isSymbolicLink()) continue; // never follow links out of the tree
    if (entry.isDirectory()) {
      walk(root, childRel, out);
      continue;
    }
    if (!entry.isFile()) continue;
    if (isSkipped(childRel)) continue;
    out.push(childRel);
  }
  return out;
}

function collect(root) {
  const files = [];
  for (const tree of MANAGED_TREES) walk(root, tree, files);
  for (const file of MANAGED_FILES) {
    if (isProtected(file) || isSkipped(file)) continue;
    if (!fs.existsSync(path.join(root, file))) {
      process.stderr.write(`build-manifest: missing MANAGED_FILE ${file}\n`);
      process.exitCode = 1;
      continue;
    }
    files.push(file);
  }
  return files.sort();
}

function main() {
  const args = process.argv.slice(2);
  const dryRun = args.includes('--dry-run');
  const rootArg = args.indexOf('--root');
  const root = rootArg === -1
    ? path.resolve(__dirname, '..')
    : path.resolve(args[rootArg + 1]);

  const files = collect(root);
  if (files.length === 0) {
    process.stderr.write('build-manifest: nothing to hash — wrong --root?\n');
    process.exit(1);
  }

  if (dryRun) {
    for (const rel of files) process.stdout.write(`${rel}\n`);
    process.stdout.write(`\n${files.length} file(s) would be hashed into ${MANIFEST_REL}\n`);
    return;
  }

  const hashed = {};
  for (const rel of files) hashed[rel] = sha256File(path.join(root, rel));

  const manifest = {
    version: VERSION,
    generated_at: new Date().toISOString(),
    files: hashed,
  };

  const out = path.join(root, MANIFEST_REL);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, `${JSON.stringify(manifest, null, 2)}\n`);
  process.stdout.write(`${MANIFEST_REL}: ${files.length} file(s), version ${VERSION}\n`);
}

main();
