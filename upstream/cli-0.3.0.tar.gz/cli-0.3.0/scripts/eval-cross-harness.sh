#!/usr/bin/env bash
# eval-cross-harness.sh — run the SAME exam under each harness and print the table.
#
# STATUS: NOT RUN. Written, syntax-checked, never executed. It spawns a real CLI
# per row, which costs money and needs credentials for every harness named. Run
# it with --dry-run first; that prints the matrix it would fill and exits 0.
#
# The exam is dev/fixtures/evaluator — a "posts" feature with four seeded defects
# and an answer key (expected.json). Its README documents what PASS means: every
# seeded criterion graded FAIL, no seeded defect excused. That is the one exam in
# this repo with a known-bad answer key, which is what makes it comparable across
# harnesses whose transcripts have nothing in common.
#
# Usage:
#   scripts/eval-cross-harness.sh [--harness claude,codex] [--agent backend-evaluator|design-evaluator|both] [--dry-run]
#
# Adding a third harness is one adapter function in scripts/agent.sh plus one
# name in --harness. That is the whole cost, and it is the point.
#
# ASSERT ON OUTCOMES ONLY — check.py's exit code against expected.json, and the
# verdict-gate verdict. Never grep a transcript, never assert on wording, never
# assert that a particular agent was spawned: that coupling is exactly what this
# eval exists to detect the absence of.
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
FIXTURE="$ROOT/dev/fixtures/evaluator"

HARNESSES="claude,codex"
AGENTS="both"
DRY=0

while [ $# -gt 0 ]; do
  case "$1" in
    --harness) HARNESSES="${2:?--harness needs a comma list}"; shift 2 ;;
    --agent)   AGENTS="${2:?--agent needs a name}"; shift 2 ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) sed -n '2,21p' "$0"; exit 0 ;;
    *) echo "eval-cross-harness: unknown argument: $1" >&2; exit 2 ;;
  esac
done

[ -d "$FIXTURE" ] || { echo "eval-cross-harness: no $FIXTURE" >&2; exit 1; }
[ -x "$HERE/agent.sh" ] || [ -f "$HERE/agent.sh" ] || { echo "eval-cross-harness: no scripts/agent.sh" >&2; exit 1; }

case "$AGENTS" in
  both)  AGENT_LIST="backend-evaluator design-evaluator" ;;
  *)     AGENT_LIST="$AGENTS" ;;
esac
HARNESS_LIST=$(echo "$HARNESSES" | tr ',' ' ')

RESULTS_DIR="$ROOT/dev/eval/results"
STAMP=$(git -C "$ROOT" rev-parse --short HEAD 2>/dev/null || echo nogit)

printf '%-18s %-18s %-8s %-8s %s\n' HARNESS AGENT GATE SCORE NOTE
printf '%-18s %-18s %-8s %-8s %s\n' ------- ----- ---- ----- ----
FAILED=0

for h in $HARNESS_LIST; do
  for a in $AGENT_LIST; do
    if [ "$DRY" = "1" ]; then
      printf '%-18s %-18s %-8s %-8s %s\n' "$h" "$a" "-" "-" "would run"
      continue
    fi
    if ! command -v "$h" >/dev/null 2>&1; then
      printf '%-18s %-18s %-8s %-8s %s\n' "$h" "$a" SKIP SKIP "no $h on PATH"
      continue
    fi

    # One throwaway project per row, assembled by the fixture's own run.sh so the
    # two paths cannot disagree about what the exam is. agent.sh is the seam:
    # AGENT_HARNESS picks the CLI, everything upstream of it is identical.
    OUT=$(AGENT_HARNESS="$h" bash "$FIXTURE/run.sh" "$a" 2>&1)
    RC=$?

    GATE=$(echo "$OUT" | grep -oE '\[VERDICT GATE\][^|]*(PASS|FAIL|UNKNOWN)' | tail -1 | grep -oE '(PASS|FAIL|UNKNOWN)$' || echo "?")
    if [ "$RC" -eq 0 ]; then SCORE=PASS; else SCORE=FAIL; FAILED=1; fi
    printf '%-18s %-18s %-8s %-8s %s\n' "$h" "$a" "${GATE:-?}" "$SCORE" "exit $RC"

    mkdir -p "$RESULTS_DIR"
    printf '%s\n' "$OUT" > "$RESULTS_DIR/$STAMP.$h.$a.log"
  done
done

echo
if [ "$DRY" = "1" ]; then
  echo "eval-cross-harness: dry run — nothing was executed."
  exit 0
fi
echo "logs: $RESULTS_DIR/$STAMP.*.log"
[ "$FAILED" = "1" ] && exit 1
exit 0
