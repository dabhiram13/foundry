#!/usr/bin/env bash
# gen-agents.sh — regenerate .agents/ and .codex/ from .claude/.
#
#   .claude/ is the source of truth. .agents/ and .codex/ are generated targets
#   for Codex, Copilot and anything else that reads them — plus a small
#   hand-owned, Codex-only remainder this script never writes and never deletes.
#
#   Codex reads: .agents/skills/<name>/SKILL.md, .codex/agents/<name>.toml,
#   .codex/hooks.json, .codex/config.toml, and the repo-root AGENTS.md.
#   It does not read .agents/agents/ or .agents/commands/, so neither is written.
#
# Usage:
#   bash scripts/gen-agents.sh [--root <path>] [--verbose]     write .agents/ + .codex/
#   bash scripts/gen-agents.sh --check [--root <path>]         no writes; exit 1 on drift
#
# Determinism: every step iterates an `LC_ALL=C sort`ed list; no dates, no $RANDOM,
# no hostname reaches any output byte. The same .claude/ produces the same output.
set -euo pipefail

CHECK=0
VERBOSE=0
ROOT=""

while [ $# -gt 0 ]; do
  case "$1" in
    --check)   CHECK=1; shift ;;
    --verbose) VERBOSE=1; shift ;;
    --root)    ROOT="${2:?--root needs a path}"; shift 2 ;;
    --root=*)  ROOT="${1#--root=}"; shift ;;
    -h|--help) sed -n '2,17p' "$0"; exit 0 ;;
    *) echo "gen-agents: unknown argument: $1" >&2; exit 2 ;;
  esac
done

if [ -z "$ROOT" ]; then
  ROOT="$(cd "$(dirname "$0")/.." && pwd)"
else
  ROOT="$(cd "$ROOT" && pwd)"
fi

SRC="$ROOT/.claude"
DST="$ROOT/.agents"
CODEX="$ROOT/.codex"
MANIFEST_NAME=".generated"

export LC_ALL=C

log()  { [ "$VERBOSE" = "1" ] && echo "  $*" || true; }
die()  { echo "gen-agents: $*" >&2; exit 1; }

# ── Hand-owned, Codex-only. Never written, never deleted. ────────────────────
# Directories and files under .agents/ that this script leaves entirely alone.
KEEP_TOP="AGENTS.md PORTING.md automations react-doctor scripts workflows"
# Plus: every .agents/skills/<name> with no .claude/skills/<name> counterpart and
# no .claude/commands/<name minus codekit-> counterpart. See PORTING.md.

# ── Frontmatter readers. Line-anchored, always. ──────────────────────────────
# A multi-line regex over the whole file truncated 34 command bodies once; every
# reader below is line-oriented and stops at the closing fence.

# fm_block <file> — the frontmatter lines, fences excluded. Empty when there is none.
fm_block() {
  awk 'NR==1 && $0=="---" {inb=1; next} inb && $0=="---" {exit} inb' "$1"
}

# fm_body <file> — the file with its frontmatter block removed.
fm_body() {
  awk 'NR==1 && $0=="---" {inb=1; next} inb && $0=="---" {inb=0; next} !inb' "$1"
}

# fm_scalar <file> <key> — first `key: value` line in the block, value only.
fm_scalar() {
  fm_block "$1" | awk -v key="$2" '
    index($0, key ":") == 1 {
      v = substr($0, length(key) + 2)
      sub(/^[ \t]+/, "", v)
      sub(/[ \t]+$/, "", v)
      print v
      exit
    }'
}

# fm_list <file> <key> — one item per line, from either YAML shape used here:
#   philosophy: [a, b]          (flow list, one line)
#   skills:                     (block list, "  - name" per line)
#     - name
fm_list() {
  fm_block "$1" | awk -v key="$2" '
    index($0, key ":") == 1 {
      rest = substr($0, length(key) + 2)
      sub(/^[ \t]+/, "", rest)
      if (substr(rest, 1, 1) == "[") {
        sub(/^\[/, "", rest); sub(/\][ \t]*$/, "", rest)
        n = split(rest, a, ",")
        for (i = 1; i <= n; i++) {
          gsub(/^[ \t]+/, "", a[i]); gsub(/[ \t]+$/, "", a[i])
          if (a[i] != "") print a[i]
        }
        inl = 0; next
      }
      if (rest != "") { print rest; inl = 0; next }
      inl = 1; next
    }
    inl && $0 ~ /^[ \t]+-[ \t]*/ {
      v = $0; sub(/^[ \t]+-[ \t]*/, "", v); gsub(/[ \t]+$/, "", v)
      if (v != "") print v
      next
    }
    inl && $0 ~ /^[^ \t]/ { inl = 0 }
  '
}

# ── Rewrites ────────────────────────────────────────────────────────────────
# Applied to generated *.md and to TOML developer_instructions only. Everything
# else is copied byte-for-byte, so a skill's scripts and JSON fixtures are never
# touched.
#
# ONLY the prefixes that actually exist under .agents/ and .codex/ are rewritten,
# plus PROMPT.md. Everything else under .claude/ — hooks/, state/, settings.json,
# workflows/, migrations/, memory-seed/, observations/, .build-active.json — has
# no generated counterpart and must keep pointing at the real file. A blanket
# `.claude/ → .agents/` produces dangling paths: it is what made the generated
# evaluators tell Codex to run `.agents/hooks/verdict-gate.py`, which does not exist.
#
# The two file-specific rules run before the directory rules so a named file is
# not rewritten twice: an agent file becomes a .codex TOML, a command file becomes
# a codekit-* skill, and only bare directory references fall through to the
# directory rules below them.
#
# ~/.claude/ and $HOME/.claude/ are protected: they name Claude Code's own home
# directory, not a path in this repo.
rewrite_paths() {
  sed -e 's#~/\.claude/#@@HOMECLAUDE@@#g' \
      -e 's#\$HOME/\.claude/#@@ENVCLAUDE@@#g' \
      -e 's#\.claude/agents/\([A-Za-z0-9_.-]*\)\.md#.codex/agents/\1.toml#g' \
      -e 's#\.claude/commands/\([A-Za-z0-9_.-]*\)\.md#.agents/skills/codekit-\1/SKILL.md#g' \
      -e 's#\.claude/agents/#.codex/agents/#g' \
      -e 's#\.claude/commands/#.agents/skills/#g' \
      -e 's#\.claude/docs/#.agents/docs/#g' \
      -e 's#\.claude/philosophy/#.agents/philosophy/#g' \
      -e 's#\.claude/skills/#.agents/skills/#g' \
      -e 's#\.claude/PROMPT\.md#.agents/PROMPT.md#g' \
      -e 's#CLAUDE\.md#AGENTS.md#g' \
      -e 's#@@HOMECLAUDE@@#~/.claude/#g' \
      -e 's#@@ENVCLAUDE@@#$HOME/.claude/#g'
}

# ── The command names, longest first, as one ERE alternation ────────────────
# Longest first so /mvp-build wins over a hypothetical /mvp. Built at runtime from
# .claude/commands/*.md, so adding a command needs no edit here.
CMD_ALT=""
build_cmd_alt() {
  local f n
  CMD_ALT="$(
    for f in "$SRC"/commands/*.md; do
      [ -f "$f" ] || continue
      n="$(basename "$f" .md)"
      printf '%s %s\n' "${#n}" "$n"
    done | sort -k1,1nr -k2,2 | awk '{ printf "%s%s", sep, $2; sep = "|" } END { print "" }'
  )"
}

# commands/, agents/ and PROMPT.md additionally take the Codex vocabulary. The
# scheduled runner is the one .claude/scripts/ file with a hand-written .agents/ twin.
#
# `/<cmd>` becomes `$codekit-<cmd>`, Codex's name for a user-invocable skill, but
# only when it is a real slash command and not a path segment: the character
# before it must be start-of-line or outside [/A-Za-z0-9._-], and the character
# after it must be end-of-line or outside [A-Za-z0-9_-]. That leaves
# `docs/setup.md` and `.agents/docs/setup-links.md` alone. sed consumes the
# character after each match, so a second identical pass catches `/a /b` pairs.
rewrite_codex() {
  local mid eol
  if [ -z "$CMD_ALT" ]; then
    sed -e 's#\.claude/scripts/#.agents/scripts/#g' \
        -e 's#claude-monitor#codex-monitor#g' \
        -e 's#Claude Code#Codex#g'
    return 0
  fi
  mid="s#(^|[^/A-Za-z0-9._-])/($CMD_ALT)([^A-Za-z0-9_-])#\1\$codekit-\2\3#g"
  eol="s#(^|[^/A-Za-z0-9._-])/($CMD_ALT)\$#\1\$codekit-\2#"
  sed -E -e "$mid" -e "$eol" \
    | sed -E -e "$mid" -e "$eol" \
    | sed -e 's#\.claude/scripts/#.agents/scripts/#g' \
          -e 's#claude-monitor#codex-monitor#g' \
          -e 's#Claude Code#Codex#g'
}

# ── TOML string escaping ────────────────────────────────────────────────────
# Basic strings process backslash escapes, so backslashes double first. Then the
# only sequence that can close a multi-line string early is `"""`.
esc_basic()     { sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }
esc_multiline() { sed -e 's/\\/\\\\/g' -e 's/"""/""\\"/g'; }

OUT_BASE=""   # tree root the files are written under (ROOT, or a temp copy under --check)
OUT_ROOT=""   # $OUT_BASE/.agents — where the manifest lives
WROTE=""      # newline-separated repo-relative paths, appended in visit order

record() {
  WROTE="$WROTE$1
"
  log "wrote $1"
}

# emit <src-abs> <rel-under-.agents> <md|verbatim> <plain|codex>
emit() {
  local src="$1" rel="$2" kind="$3" vocab="$4" dst="$OUT_BASE/.agents/$2"
  mkdir -p "$(dirname "$dst")"
  if [ "$kind" = "md" ]; then
    if [ "$vocab" = "codex" ]; then
      rewrite_paths < "$src" | rewrite_codex > "$dst"
    else
      rewrite_paths < "$src" > "$dst"
    fi
  else
    cp -p "$src" "$dst"
  fi
  record ".agents/$rel"
}

# emit_tree <src-dir-abs> <rel-under-.agents> <plain|codex>
emit_tree() {
  local srcdir="$1" reldir="$2" vocab="$3" f rel kind
  [ -d "$srcdir" ] || return 0
  find "$srcdir" -type f -print | sort | while IFS= read -r f; do
    rel="${f#"$srcdir"/}"
    case "$rel" in
      .DS_Store|*/.DS_Store) continue ;;
      *__pycache__*|*.pyc)   continue ;;
    esac
    case "$rel" in
      *.md) kind=md ;;
      *)    kind=verbatim ;;
    esac
    echo "$reldir/$rel|$f|$kind|$vocab"
  done
}

# ── .codex/agents/<name>.toml ───────────────────────────────────────────────
# Codex requires name, description, developer_instructions; model_reasoning_effort
# and sandbox_mode are the only optional keys this tree has an honest value for.
# model is never emitted: the Claude model names are not Codex model names.

# sandbox_for <agent-file> — read-only when the agent cannot write, else workspace-write.
sandbox_for() {
  local f="$1" dis tools
  dis="$(fm_scalar "$f" disallowedTools)"
  tools="$(fm_scalar "$f" tools)"
  if [ -n "$dis" ]; then
    if echo "$dis" | grep -qw Write && echo "$dis" | grep -qw Edit; then
      echo "read-only"; return 0
    fi
  fi
  if [ -n "$tools" ]; then
    if echo "$tools" | grep -qw Write || echo "$tools" | grep -qw Edit; then
      echo "workspace-write"; return 0
    fi
    echo "read-only"; return 0
  fi
  echo "workspace-write"
}

# backtick_join <prefix> <suffix> — one item per line on stdin → `p<item>s`, `p<item>s`
backtick_join() {
  awk -v p="$1" -v s="$2" '{ printf "%s`%s%s%s`", sep, p, $0, s; sep = ", " } END { print "" }'
}

# agent_sections <agent-file> — the read-lists appended to developer_instructions.
# .codex/hooks.json registers subagent-prime.sh on SubagentStart, which injects the
# same philosophy and skills when Codex reports agent_type; these lists are the
# fallback for when it does not.
agent_sections() {
  local f="$1" items s
  items="$(fm_list "$f" philosophy)"
  if [ -n "$items" ]; then
    printf '\n## Philosophy\n\nRead before starting: %s\n' \
      "$(printf '%s\n' "$items" | backtick_join '.agents/philosophy/' '.md')"
  fi
  items="$(fm_list "$f" skills)"
  if [ -n "$items" ]; then
    printf '\n## Skills\n\nRead before starting: %s\n' \
      "$(printf '%s\n' "$items" | backtick_join '.agents/skills/' '/SKILL.md')"
  fi
  items="$(fm_list "$f" mcpServers)"
  if [ -n "$items" ]; then
    printf '\n## MCP\n\n'
    printf '%s\n' "$items" | while IFS= read -r s; do
      [ -n "$s" ] || continue
      printf 'This agent expects the `%s` MCP server — see `.codex/config.toml`.\n' "$s"
    done
  fi
}

# emit_agent_toml <src-abs> <name>
emit_agent_toml() {
  local src="$1" name="$2" rel=".codex/agents/$2.toml" dst
  local desc effort sandbox
  dst="$OUT_BASE/$rel"
  desc="$(fm_scalar "$src" description)"
  [ -n "$desc" ] || die "agents/$name.md has no 'description:' — Codex requires one"
  effort="$(fm_scalar "$src" effort)"
  case "$effort" in
    low|medium|high|xhigh|max) ;;
    *) effort="" ;;
  esac
  sandbox="$(sandbox_for "$src")"
  mkdir -p "$(dirname "$dst")"
  {
    echo "# generated by scripts/gen-agents.sh from .claude/agents/$name.md — edit the source, not this"
    printf 'name = "%s"\n' "$name"
    printf 'description = "%s"\n' "$(printf '%s' "$desc" | esc_basic)"
    if [ -n "$effort" ]; then printf 'model_reasoning_effort = "%s"\n' "$effort"; fi
    printf 'sandbox_mode = "%s"\n' "$sandbox"
    printf 'developer_instructions = """\n'
    {
      fm_body "$src" | rewrite_paths | rewrite_codex
      agent_sections "$src"
    } | esc_multiline
    printf '"""\n'
  } > "$dst"
  record "$rel"
}

# ── .agents/skills/codekit-<cmd>/SKILL.md ───────────────────────────────────
# Codex shows a skill with user-invocable: true as $name. disable-model-invocation
# keeps the 34 of them out of the model's own skill list.

# yaml_scalar <text> — plain when it is unambiguous, double-quoted when it is not.
yaml_scalar() {
  local v="$1"
  case "$v" in
    *": "*|*" #"*|\[*|\{*|\"*|\'*|\&*|\**|\!*|\|*|\>*|\%*|\@*|\`*|-\ *|"")
      printf '"%s"' "$(printf '%s' "$v" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g')" ;;
    *) printf '%s' "$v" ;;
  esac
}

# emit_command_skill <src-abs> <cmd>
emit_command_skill() {
  local src="$1" cmd="$2" rel=".agents/skills/codekit-$2/SKILL.md" dst
  local desc hint
  dst="$OUT_BASE/$rel"
  desc="$(fm_scalar "$src" description)"
  if [ -z "$desc" ]; then
    desc="$(grep -m1 '^# ' "$src" 2>/dev/null | sed 's/^#[[:space:]]*//' || true)"
  fi
  if [ -z "$desc" ]; then desc="codekit /$cmd"; fi
  desc="$(printf '%s\n' "$desc" | rewrite_paths | rewrite_codex)"
  hint="$(fm_scalar "$src" argument-hint)"
  mkdir -p "$(dirname "$dst")"
  {
    echo "---"
    echo "name: codekit-$cmd"
    echo "description: $(yaml_scalar "$desc")"
    if [ -n "$hint" ]; then echo "argument-hint: $(yaml_scalar "$hint")"; fi
    echo "user-invocable: true"
    echo "disable-model-invocation: true"
    echo "---"
    echo
    fm_body "$src" | rewrite_paths | rewrite_codex
  } > "$dst"
  record "$rel"
}

# ── .codex/hooks.json ───────────────────────────────────────────────────────
# The template below mirrors .claude/hooks/hooks.json registration for registration.
# Two differences, both forced: the command is a plain relative invocation because
# Codex has no ${CLAUDE_PLUGIN_ROOT} and runs hooks with cwd = the session cwd, and
# the interpreter is explicit because the files are not guaranteed executable after
# a copy. Event names come only from Codex's documented set:
#   SessionStart PermissionRequest PreToolUse PostToolUse PreCompact PostCompact
#   SessionEnd UserPromptSubmit SubagentStart SubagentStop Stop
emit_hooks_json() {
  local rel=".codex/hooks.json" dst h
  dst="$OUT_BASE/$rel"
  mkdir -p "$(dirname "$dst")"
  cat > "$dst" <<'HOOKS_JSON'
{
  "description": "generated by scripts/gen-agents.sh from .claude/hooks/hooks.json — edit the source; the commands run scripts in .claude/hooks/, present after npx buildthisnow init --copy",
  "hooks": {
    "SessionStart": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/orchestrator-init.sh",
            "timeout": 10
          },
          {
            "type": "command",
            "command": "bash .claude/hooks/license-notice.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "node .claude/hooks/skill-activate.js",
            "timeout": 10
          }
        ]
      }
    ],
    "SubagentStart": [
      {
        "matcher": "planner|db-architect|backend|connector|designer|build-fixer|ts-expert|quality-gate|complete|api-tester|flow-tester|perf-tester|sentry-analyst|slop-cleaner|security-auditor|critic|architect|spec-critic|ux-critic|discovery-critic",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/subagent-prime.sh",
            "timeout": 10
          },
          {
            "type": "command",
            "command": "bash .claude/hooks/progress-track.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "SubagentStop": [
      {
        "matcher": "planner|db-architect|backend|connector|designer|backend-evaluator|design-evaluator|build-fixer|ts-expert|quality-gate|complete|api-tester|flow-tester|perf-tester|sentry-analyst",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/progress-track.sh",
            "timeout": 5
          },
          {
            "type": "command",
            "command": "bash .claude/hooks/verify-deliverables.sh",
            "timeout": 30
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/guardrails.sh",
            "timeout": 5
          }
        ]
      },
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/suggest-compact.sh",
            "timeout": 5
          }
        ]
      },
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "command",
            "command": "python3 .claude/hooks/brief-budget.py",
            "timeout": 5
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/auto-format.sh",
            "timeout": 15
          }
        ]
      }
    ],
    "PreCompact": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "node .claude/hooks/pre-compact-save.js",
            "timeout": 10
          }
        ]
      }
    ],
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/verify-stop.sh",
            "timeout": 300
          },
          {
            "type": "command",
            "command": "node .claude/hooks/persistent-build.js",
            "timeout": 5
          }
        ]
      }
    ]
  }
}
HOOKS_JSON
  # Template rot is silent otherwise: warn when the source registers a script the
  # template does not name. Never fails — B's two hooks land before this is true.
  if [ -f "$SRC/hooks/hooks.json" ]; then
    { grep -o 'hooks/[A-Za-z0-9_.-]*' "$SRC/hooks/hooks.json" || true; } | sed 's#^hooks/##' | sort -u \
      | while IFS= read -r h; do
          [ -n "$h" ] || continue
          grep -q "hooks/$h" "$dst" || \
            echo "gen-agents: warning: .claude/hooks/hooks.json registers $h, .codex/hooks.json template does not" >&2
        done
  fi
  record "$rel"
}

# ── .codex/config.toml ──────────────────────────────────────────────────────
emit_config_toml() {
  local rel=".codex/config.toml" dst
  dst="$OUT_BASE/$rel"
  mkdir -p "$(dirname "$dst")"
  python3 - "$ROOT/.mcp.json" > "$dst" <<'PY'
import json, re, sys

src = json.load(open(sys.argv[1]))
servers = src.get("mcpServers", {})

def key(k):
    return k if re.match(r'^[A-Za-z0-9_-]+$', k) else '"%s"' % k.replace('\\', '\\\\').replace('"', '\\"')

def s(v):
    return '"%s"' % str(v).replace('\\', '\\\\').replace('"', '\\"')

out = [
    "# generated by scripts/gen-agents.sh from .mcp.json — edit the source, not this",
    "# Codex does not expand ${VAR} inside args: such an arg reaches the server verbatim.",
    "# env_vars names the variables Codex forwards from the environment instead.",
    "# Override or add servers in ~/.codex/config.toml, same [mcp_servers.*] table.",
]
for name in sorted(servers):
    cfg = servers[name] or {}
    out.append("")
    out.append("[mcp_servers.%s]" % key(name))
    out.append("command = %s" % s(cfg.get("command", "")))
    out.append("args = [%s]" % ", ".join(s(a) for a in (cfg.get("args") or [])))
    env_vars = []
    for k in sorted((cfg.get("env") or {}).keys()):
        m = re.match(r'^\$\{([A-Za-z_][A-Za-z0-9_]*)\}$', str(cfg["env"][k]))
        if m:
            env_vars.append(m.group(1))
    if env_vars:
        out.append("env_vars = [%s]" % ", ".join(s(v) for v in env_vars))
print("\n".join(out))
PY
  record "$rel"
}

# ── Pre-flight (both modes; fail before writing anything) ────────────────────
preflight() {
  [ -d "$SRC" ] || die "no $SRC — run this from the codekit repo"
  [ -d "$DST" ] || die "no $DST — this script regenerates a subset, it does not create the tree"
  [ -f "$ROOT/.mcp.json" ] || die "no $ROOT/.mcp.json — .codex/config.toml is generated from it"

  local n
  n=$(grep -c '^@AGENTS\.md$' "$ROOT/CLAUDE.md" 2>/dev/null || true)
  [ "${n:-0}" = "1" ] || die "CLAUDE.md must contain exactly one '@AGENTS.md' import line (found ${n:-0})"
  if grep -q '^## Tech Stack$' "$ROOT/CLAUDE.md" 2>/dev/null; then
    die "CLAUDE.md has grown a copy of the shared rules ('## Tech Stack') — they belong in AGENTS.md"
  fi

  # Zed and friends: first match wins across these names, so a stray legacy file
  # silently shadows AGENTS.md.
  local shadow
  for shadow in .rules .cursorrules .windsurfrules .clinerules AGENT.md .github/copilot-instructions.md; do
    [ -e "$ROOT/$shadow" ] && die "$shadow exists at the repo root and shadows AGENTS.md — remove it"
  done

  # A .claude skill named codekit-<cmd> would fight the generated command skill
  # for the same .agents/skills/ directory. Checked before the SKILL.md loop, so
  # the failure names the collision rather than the missing file.
  local d name
  for d in "$SRC"/commands/*.md; do
    [ -f "$d" ] || continue
    name="codekit-$(basename "$d" .md)"
    [ -d "$SRC/skills/$name" ] && die ".claude/skills/$name collides with the generated command skill for /$(basename "$d" .md)"
  done

  for d in "$SRC"/skills/*/; do
    [ -d "$d" ] || continue
    name=$(basename "$d")
    [ -f "$d/SKILL.md" ] || die "skills/$name has no SKILL.md"
    grep -q '^name:' "$d/SKILL.md" || echo "gen-agents: warning: skills/$name/SKILL.md has no 'name:' frontmatter key" >&2
  done
  return 0
}

generate() {
  local rel src kind vocab name
  # 1..3: the trees Codex reads as-is. 4: PROMPT.md. 5: the settings snapshot
  # Codex operators read. Then the agents, the command skills, and the two
  # .codex/ config files.
  {
    emit_tree "$SRC/docs"       "docs"       plain
    emit_tree "$SRC/philosophy" "philosophy" plain
    emit_tree "$SRC/skills"     "skills"     plain
    echo "PROMPT.md|$SRC/PROMPT.md|md|codex"
    echo "reference/claude-settings.json|$SRC/settings.json|verbatim|plain"
  } > "$WORK/plan.txt"

  while IFS='|' read -r rel src kind vocab; do
    [ -n "$rel" ] || continue
    emit "$src" "$rel" "$kind" "$vocab"
  done < "$WORK/plan.txt"

  find "$SRC/agents" -maxdepth 1 -type f -name '*.md' -print | sort > "$WORK/agents.txt"
  while IFS= read -r src; do
    [ -n "$src" ] || continue
    name="$(basename "$src" .md)"
    emit_agent_toml "$src" "$name"
  done < "$WORK/agents.txt"

  find "$SRC/commands" -maxdepth 1 -type f -name '*.md' -print | sort > "$WORK/commands.txt"
  while IFS= read -r src; do
    [ -n "$src" ] || continue
    name="$(basename "$src" .md)"
    emit_command_skill "$src" "$name"
  done < "$WORK/commands.txt"

  emit_hooks_json
  emit_config_toml

  printf '%s' "$WROTE" | grep -v '^$' | sort > "$OUT_ROOT/$MANIFEST_NAME"
}

# ── The set of paths this script owns ────────────────────────────────────────
# Wholly-generated roots, one skill directory per .claude/skills/<name> and per
# .claude/commands/<cmd>, and the three .codex/ targets. Everything else under
# .agents/ is hand-owned and outside every delete step.
owned_roots() {
  local d name
  for d in docs philosophy reference; do
    [ -d "$DST/$d" ] && echo ".agents/$d"
  done
  [ -f "$DST/PROMPT.md" ] && echo ".agents/PROMPT.md"
  for d in "$SRC"/skills/*/; do
    [ -d "$d" ] || continue
    name=$(basename "$d")
    [ -d "$DST/skills/$name" ] && echo ".agents/skills/$name"
  done
  for d in "$SRC"/commands/*.md; do
    [ -f "$d" ] || continue
    name="codekit-$(basename "$d" .md)"
    [ -d "$DST/skills/$name" ] && echo ".agents/skills/$name"
  done
  [ -d "$CODEX/agents" ] && echo ".codex/agents"
  [ -f "$CODEX/hooks.json" ] && echo ".codex/hooks.json"
  [ -f "$CODEX/config.toml" ] && echo ".codex/config.toml"
  return 0
}

# Every file that currently sits inside an owned root.
owned_files() {
  local r
  owned_roots | sort | while IFS= read -r r; do
    if [ -f "$ROOT/$r" ]; then
      echo "$r"
    else
      find "$ROOT/$r" -type f -print 2>/dev/null | sed "s#^$ROOT/##"
    fi
  done | sort
}

# ── Delete step: bounded to owned roots, never `rm -rf .agents/` ─────────────
sweep() {
  local p
  owned_files > "$WORK/before.txt"
  while IFS= read -r p; do
    [ -n "$p" ] || continue
    if ! grep -qxF "$p" "$DST/$MANIFEST_NAME"; then
      rm -f "$ROOT/$p"
      echo "  removed $p"
    fi
  done < "$WORK/before.txt"
  # A skill deleted from .claude/skills, or a whole generated root this script no
  # longer writes (.agents/agents/, .agents/commands/), leaves its copy behind; the
  # previous manifest is the only record that it was ours.
  if [ -f "$WORK/old-manifest.txt" ]; then
    while IFS= read -r p; do
      [ -n "$p" ] || continue
      case "$p" in .agents/*|.codex/*) ;; *) continue ;; esac
      if ! grep -qxF "$p" "$DST/$MANIFEST_NAME" && [ -f "$ROOT/$p" ]; then
        rm -f "$ROOT/$p"
        echo "  removed $p (dropped from .claude/)"
      fi
    done < "$WORK/old-manifest.txt"
  fi
  local d
  for d in "$DST/agents" "$DST/commands" "$DST/docs" "$DST/philosophy" "$DST/skills" \
           "$DST/reference" "$CODEX/agents"; do
    [ -d "$d" ] && find "$d" -type d -empty -delete 2>/dev/null || true
  done
  return 0
}

WORK="$(mktemp -d "${TMPDIR:-/tmp}/gen-agents.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

preflight
build_cmd_alt

if [ "$CHECK" = "1" ]; then
  OUT_BASE="$WORK/out"
  OUT_ROOT="$OUT_BASE/.agents"
  mkdir -p "$OUT_ROOT"
  generate
  DRIFT=0
  while IFS= read -r p; do
    [ -n "$p" ] || continue
    if [ ! -f "$ROOT/$p" ]; then
      echo "DRIFT missing:  $p"; DRIFT=1; continue
    fi
    if ! cmp -s "$OUT_BASE/$p" "$ROOT/$p"; then
      echo "DRIFT changed:  $p"; DRIFT=1
    fi
  done < "$OUT_ROOT/$MANIFEST_NAME"
  # Anything sitting inside a root this script owns that it did not just write.
  owned_files > "$WORK/before.txt"
  while IFS= read -r p; do
    [ -n "$p" ] || continue
    case "$p" in */"$MANIFEST_NAME") continue ;; esac
    grep -qxF "$p" "$OUT_ROOT/$MANIFEST_NAME" || { echo "DRIFT extra:    $p"; DRIFT=1; }
  done < "$WORK/before.txt"
  if [ -f "$DST/$MANIFEST_NAME" ]; then
    if ! cmp -s "$OUT_ROOT/$MANIFEST_NAME" "$DST/$MANIFEST_NAME"; then
      echo "DRIFT changed:  .agents/$MANIFEST_NAME"; DRIFT=1
    fi
  else
    echo "DRIFT missing:  .agents/$MANIFEST_NAME"; DRIFT=1
  fi
  if [ "$DRIFT" = "1" ]; then
    echo "gen-agents: .agents/ and .codex/ have drifted from .claude/. Run: bash scripts/gen-agents.sh" >&2
    exit 1
  fi
  echo "gen-agents: .agents/ and .codex/ are in sync with .claude/ ($(wc -l < "$OUT_ROOT/$MANIFEST_NAME" | tr -d ' ') generated files)"
  exit 0
fi

OUT_BASE="$ROOT"
OUT_ROOT="$DST"
if [ -f "$DST/$MANIFEST_NAME" ]; then cp "$DST/$MANIFEST_NAME" "$WORK/old-manifest.txt"; fi
generate
sweep
echo "gen-agents: wrote $(wc -l < "$DST/$MANIFEST_NAME" | tr -d ' ') files under .agents/ and .codex/"
echo "gen-agents: hand-owned and untouched: $KEEP_TOP, and every .agents/skills/<name> with no .claude/ counterpart"
