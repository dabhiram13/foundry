#!/usr/bin/env bash
# lint-patterns.sh — the harness's objective rules, in one place, as greps.
#
# Every rule here is a known fact with one right answer and a counterexample that
# shipped. The judgment behind each one lives in .claude/philosophy/ and is not
# restated here. Evaluators cite findings by rule id; the same script runs at
# pre-commit, in CI and in the Stop hook through scripts/verify.sh.
#
# Usage:
#   scripts/lint-patterns.sh [options] <path> [<path>...]
#   scripts/lint-patterns.sh [options] --files <file> [<file>...]
#
# Options:
#   --warn-only      report FAILs as WARNs; never exit 1
#   --rules a,b,c    run only these rule ids
#   --staged         ratchet on the git index: only lines being committed count; also runs css-var-rename
#   --diff-base REF  ratchet vs REF: only lines added since REF (working tree included) count
#   --list           print rule ids + severities and exit
#
# Ratchet: with --staged / --diff-base, findings on lines that already existed are counted as
# pre-existing and neither listed nor blocking (file-level findings at :0 always count).
# Exclusions: node_modules, .next, dist, tests, *.d.ts, *.config.*, components/ui/ (shadcn), and
# every glob listed in a .lint-patterns-ignore file at the repo root (one per line, # comments).
#
# Output:  FAIL|WARN <rule> <file>:<line> — <message>
#          LINT-PATTERNS: <n> FAIL, <n> WARN (<files> files)[ · <k> pre-existing not counted (ratchet vs REF)]
# Exit:    1 if any FAIL, else 0.

# (no set -u: empty-array expansion is an error under macOS bash 3.2)

WARN_ONLY=0
ONLY_RULES=""
STAGED=0
DIFF_BASE=""
LIST=0
MODE="paths"
ARGS=()

while [ $# -gt 0 ]; do
  case "$1" in
    --warn-only) WARN_ONLY=1 ;;
    --rules) ONLY_RULES="$2"; shift ;;
    --rules=*) ONLY_RULES="${1#--rules=}" ;;
    --staged) STAGED=1 ;;
    --diff-base) DIFF_BASE="$2"; shift ;;
    --diff-base=*) DIFF_BASE="${1#--diff-base=}" ;;
    --list) LIST=1 ;;
    --files) MODE="files" ;;
    -h|--help) sed -n '2,22p' "$0"; exit 0 ;;
    *) ARGS+=("$1") ;;
  esac
  shift
done

# ─── Rule table (id  severity  what) ─────────────────────────────
RULES="
auth-getuser              FAIL  getSession()/getUser() — server-side auth reads getClaims() only
suspense-key              FAIL  key={} on <Suspense> destroys children on every change; startTransition instead
route-segment-config      FAIL  export const dynamic/revalidate/fetchCache/runtime is dead under cacheComponents
invalidate-queries        FAIL  invalidateQueries as the cache authority; server tag + router.refresh() (WARN when client queries coexist)
http-client-mutation      FAIL  mutation through the HTTP client; mutations go through .actionable() server actions
use-cache-receipt         FAIL  'use cache' without cacheLife() + cacheTag() in the same file
use-client-page           FAIL  'use client' on page.tsx / layout.tsx; the boundary is the lowest leaf
raw-palette               FAIL  raw Tailwind palette / bg-white / text-black / hsl(var()) — semantic tokens only
admin-client-placement    FAIL  createAdminClient() outside inngest/ (WARN under app/api/)
service-role-exposure     FAIL  service-role key referenced outside inngest/ and lib/supabase/admin
sql-interpolation         FAIL  string interpolation inside a SQL template
definer-search-path       FAIL  SECURITY DEFINER function without SET search_path
any-type                  FAIL  any / as unknown as / @ts-ignore
actionable-missing        FAIL  a feature with mutation procedures and no features/<f>/actions.ts using .actionable()
secure-object-mutation    WARN  mutation input declared with z.object() — secureObject() expected
pii-trigger-log           WARN  to_jsonb(NEW|OLD) in SQL — PII in trigger logs if the table holds email/tokens
edge-cors-wildcard        WARN  Access-Control-Allow-Origin: * on an edge function
edge-verify-jwt-off       WARN  verify_jwt = false in supabase/config.toml
ts-expect-error           WARN  @ts-expect-error
eslint-disable            WARN  eslint-disable comment
console-log               WARN  console.log in app code
css-var-rename            FAIL  (--staged) a CSS variable removed or renamed in globals.css — values may change, names may not
"

if [ "$LIST" = "1" ]; then
  echo "$RULES" | sed '/^$/d'
  exit 0
fi

rule_on() {
  [ -z "$ONLY_RULES" ] && return 0
  case ",$ONLY_RULES," in *",$1,"*) return 0 ;; esac
  return 1
}

# ─── File collection ─────────────────────────────────────────────
is_code() {
  case "$1" in
    *.ts|*.tsx|*.js|*.jsx|*.mjs|*.cjs|*.sql|*.toml|*.css) return 0 ;;
    *) return 1 ;;
  esac
}
IGNORE_GLOBS=()
if [ -f .lint-patterns-ignore ]; then
  while IFS= read -r line; do
    line="${line%%#*}"; line="$(echo "$line" | tr -d '[:space:]')"
    [ -z "$line" ] && continue
    case "$line" in /*|./*) ;; *) line="./$line" ;; esac
    IGNORE_GLOBS+=("$line")
  done < .lint-patterns-ignore
fi
is_excluded() {
  case "$1" in
    */node_modules/*|*/.next/*|*/dist/*|*/build/*|*/coverage/*|*/.git/*) return 0 ;;
    */tests/*|*/__tests__/*|*.test.*|*.spec.*|*/e2e/*|*/playwright-report/*) return 0 ;;
    *.d.ts|*/scan-malware.mjs|*.config.ts|*.config.js|*.config.mjs|*.config.cjs) return 0 ;;
    */components/ui/*) return 0 ;;   # shadcn primitives — vendored, never edited by hand
  esac
  local g
  for g in ${IGNORE_GLOBS[@]+"${IGNORE_GLOBS[@]}"}; do
    case "$1" in $g|$g/*|$g*) return 0 ;; esac
  done
  return 1
}

# Paths are normalised to start with ./ or / so that directory patterns (*/app/*,
# */supabase/functions/*) match whether the caller passed webapp/x or x from the app root.
norm() { case "$1" in /*|./*) echo "$1" ;; *) echo "./$1" ;; esac; }

FILES=()
if [ "$MODE" = "files" ]; then
  for f in "${ARGS[@]}"; do
    [ -f "$f" ] || continue
    is_code "$f" || continue
    f=$(norm "$f")
    is_excluded "$f" && continue
    FILES+=("$f")
  done
else
  [ ${#ARGS[@]} -eq 0 ] && { echo "lint-patterns: no path given (see --help)" >&2; exit 2; }
  for p in "${ARGS[@]}"; do
    if [ -f "$p" ]; then
      p=$(norm "$p")
      is_code "$p" && ! is_excluded "$p" && FILES+=("$p")
    elif [ -d "$p" ]; then
      p=$(norm "${p%/}")
      while IFS= read -r f; do
        is_excluded "$f" && continue
        FILES+=("$f")
      done < <(find "$p" -type f \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.jsx' -o -name '*.mjs' -o -name '*.cjs' -o -name '*.sql' -o -name '*.toml' -o -name '*.css' \) \
                -not -path '*/node_modules/*' -not -path '*/.next/*' -not -path '*/dist/*' -not -path '*/build/*' -not -path '*/coverage/*' 2>/dev/null | sort)
    fi
  done
fi

if [ ${#FILES[@]} -eq 0 ]; then
  echo "LINT-PATTERNS: 0 FAIL, 0 WARN (0 files)"
  exit 0
fi

TS=(); SQL=(); TOML=(); CSS=()
for f in "${FILES[@]}"; do
  case "$f" in
    *.ts|*.tsx|*.js|*.jsx|*.mjs|*.cjs) TS+=("$f") ;;
    *.sql) SQL+=("$f") ;;
    *.toml) TOML+=("$f") ;;
    *.css) CSS+=("$f") ;;
  esac
done

# ─── Ratchet: which lines are new? ───────────────────────────────
# ADDED holds "path:line" for every line added in the index (--staged) or since
# DIFF_BASE (working tree included). Untracked files are entirely new.
ADDED=""
RATCHET=""
if [ "$STAGED" = "1" ] || [ -n "$DIFF_BASE" ]; then
  ADDED=$(mktemp 2>/dev/null || echo "/tmp/lint-added-$$")
  if [ "$STAGED" = "1" ]; then RATCHET="index"; DIFF_ARGS=(--cached); else RATCHET="$DIFF_BASE"; DIFF_ARGS=("$DIFF_BASE"); fi
  {
    git diff -U0 --no-color "${DIFF_ARGS[@]}" -- "${FILES[@]}" 2>/dev/null | awk '
      /^\+\+\+ / { f=$2; sub(/^b\//,"",f); next }
      /^@@/ { s=$3; sub(/^\+/,"",s); n=split(s,p,","); start=p[1]+0; cnt=(n>1)?p[2]+0:1; for(i=0;i<cnt;i++) print f ":" (start+i) }'
    # untracked files: every line is new
    for f in "${FILES[@]}"; do
      rel="${f#./}"
      if ! git ls-files --error-unmatch -- "$rel" >/dev/null 2>&1; then
        n=$(wc -l < "$f" | tr -d ' '); i=1; while [ "$i" -le "$n" ]; do echo "$rel:$i"; i=$((i+1)); done
      fi
    done
  } | sort -u > "$ADDED"
fi

# ─── Emit ────────────────────────────────────────────────────────
NFAIL=0; NWARN=0; NPRE=0
emit() { # sev rule loc msg
  local sev="$1"
  local loc="$3"; loc="${loc#./}"
  if [ -n "$RATCHET" ]; then
    local ln="${loc##*:}"
    if [ "$ln" = "0" ]; then
      # file-level finding (actionable-missing, css-var-rename): counts only if this feature/dir was touched
      local d; d=$(dirname "${loc%:0}")
      if ! grep -q -- "^$d/" "$ADDED" 2>/dev/null; then NPRE=$((NPRE+1)); return 0; fi
    elif ! grep -qxF -- "$loc" "$ADDED" 2>/dev/null; then
      NPRE=$((NPRE+1)); return 0
    fi
  fi
  if [ "$sev" = "FAIL" ] && [ "$WARN_ONLY" = "1" ]; then sev="WARN"; fi
  if [ "$sev" = "FAIL" ]; then NFAIL=$((NFAIL+1)); else NWARN=$((NWARN+1)); fi
  printf '%s %s %s — %s\n' "$sev" "$2" "$loc" "$4"
}
# grep helper: prints file:line for a pattern across a file list; never fails the script
g() { # pattern files...
  local pat="$1"; shift
  [ $# -eq 0 ] && return 0
  grep -nE -- "$pat" "$@" 2>/dev/null | cut -d: -f1,2
  return 0
}
# g1: same, but for a single file (avoids grep omitting the filename)
g1() { grep -nE -- "$1" "$2" 2>/dev/null | cut -d: -f1 | sed "s|^|$2:|"; return 0; }

# Some rules key on the Next config.
CACHE_COMPONENTS=0
for cfg in webapp/next.config.ts webapp/next.config.mjs webapp/next.config.js next.config.ts next.config.mjs next.config.js; do
  [ -f "$cfg" ] && grep -q 'cacheComponents' "$cfg" 2>/dev/null && CACHE_COMPONENTS=1
done

# ─── TS/TSX rules ────────────────────────────────────────────────
if [ ${#TS[@]} -gt 0 ]; then

  if rule_on auth-getuser; then
    for f in "${TS[@]}"; do
      case "$f" in */supabase/functions/*) continue ;; esac   # edge functions verify a bearer token with getUser(jwt)
      while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL auth-getuser "$loc" "getSession()/getUser() — use getClaims()"; done \
        < <(g1 '(\.|[^A-Za-z0-9_])(getUser|getSession)\(' "$f")
    done
  fi

  if rule_on suspense-key; then
    while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL suspense-key "$loc" "key={} on <Suspense> — remove; wrap the change in startTransition"; done \
      < <(g '<Suspense[^>]*[[:space:]]key=' "${TS[@]}")
  fi

  if rule_on route-segment-config; then
    sev=FAIL; [ "$CACHE_COMPONENTS" = "1" ] || sev=WARN
    for f in "${TS[@]}"; do
      case "$f" in */app/*) ;; *) continue ;; esac
      case "$f" in */opengraph-image.*|*/twitter-image.*|*/icon.*|*/apple-icon.*|*/sitemap.*|*/robots.*|*/manifest.*) continue ;; esac   # metadata routes keep runtime/size exports
      while IFS= read -r loc; do [ -n "$loc" ] && emit "$sev" route-segment-config "$loc" "route segment config is dead with cacheComponents; use connection() or 'use cache'"; done \
        < <(g1 '^export const (dynamic|revalidate|fetchCache|runtime)[[:space:]]*=' "$f")
    done
  fi

  if rule_on invalidate-queries; then
    for f in "${TS[@]}"; do
      hits=$(g1 'invalidateQueries' "$f"); [ -z "$hits" ] && continue
      # dual-cache case: the feature also owns client queries → WARN, not FAIL
      fdir=$(dirname "$f")
      case "$f" in */features/*) fdir=$(echo "$f" | sed -E 's|(.*/features/[^/]+)/.*|\1|') ;; esac
      if grep -rqE 'useInfiniteQuery|useQuery\(' "$fdir" 2>/dev/null; then
        while IFS= read -r loc; do emit WARN invalidate-queries "$loc" "client cache invalidated — confirm the server tag is invalidated too (cacheInvalidator/updateTag)"; done <<< "$hits"
      else
        while IFS= read -r loc; do emit FAIL invalidate-queries "$loc" "no client queries here — server tag + router.refresh() is the invalidation"; done <<< "$hits"
      fi
    done
  fi

  if rule_on http-client-mutation; then
    for f in "${TS[@]}"; do
      case "$f" in */actions.ts) continue ;; esac
      while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL http-client-mutation "$loc" "mutation via the HTTP client — call the .actionable() server action"; done \
        < <(g1 'client\.(protected|public)\.[A-Za-z0-9_.]*\.(create|update|delete|remove|toggle|add|set|mark|archive|restore|reorder|upsert|send|submit|bulk)[A-Za-z0-9_]*\(' "$f")
    done
  fi

  if rule_on use-cache-receipt; then
    for f in "${TS[@]}"; do
      grep -qE "['\"]use cache(: private)?['\"]" "$f" 2>/dev/null || continue
      line=$(grep -nE "['\"]use cache(: private)?['\"]" "$f" | head -1 | cut -d: -f1)
      grep -q 'cacheLife(' "$f" || emit FAIL use-cache-receipt "$f:$line" "'use cache' without cacheLife()"
      if ! grep -q 'cacheTag(' "$f"; then
        if grep -qE 'caller\.|ORPCCaller|supabase|fetch\(|\.from\(|\.rpc\(|client\.(protected|public)\.|sql`' "$f"; then
          emit FAIL use-cache-receipt "$f:$line" "'use cache' reads data but has no cacheTag() — nothing can invalidate it"
        else
          emit WARN use-cache-receipt "$f:$line" "'use cache' without cacheTag() — fine for a static shell; add a tag the moment it reads data"
        fi
      fi
    done
  fi

  if rule_on use-client-page; then
    for f in "${TS[@]}"; do
      case "$f" in */page.tsx|*/layout.tsx|*/page.jsx|*/layout.jsx) ;; *) continue ;; esac
      while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL use-client-page "$loc" "'use client' on a page/layout — push it to the lowest interactive leaf"; done \
        < <(g1 "^['\"]use client['\"]" "$f")
    done
  fi

  if rule_on raw-palette; then
    HUES='(red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose|slate|gray|grey|zinc|neutral|stone)'
    PFX='(bg|text|border|ring|from|via|to|fill|stroke|divide|outline|placeholder|accent|caret|decoration|shadow)'
    for f in "${TS[@]}"; do
      case "$f" in */emails/*|*/email/*|*.email.tsx|*/react-email/*) continue ;; esac
      while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL raw-palette "$loc" "raw palette class — use a semantic token (text-destructive, bg-muted, text-primary-foreground…)"; done \
        < <(g1 "(^|[^A-Za-z0-9_-])(${PFX}-${HUES}-[0-9]{2,3}|(bg|text)-(white|black))([^A-Za-z0-9_-]|$)" "$f")
      while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL raw-palette "$loc" "hsl(var(--x)) — Tailwind v4 tokens are plain var(--x) / utility classes"; done \
        < <(g1 'hsl\(var\(' "$f")
    done
  fi

  if rule_on admin-client-placement; then
    for f in "${TS[@]}"; do
      case "$f" in */inngest/*|*/lib/*|*/supabase/functions/*|*/scripts/*) continue ;; esac   # lib/ is server infrastructure (orpc context, credits)
      sev=FAIL; case "$f" in */app/api/*) sev=WARN ;; esac
      while IFS= read -r loc; do [ -n "$loc" ] && emit "$sev" admin-client-placement "$loc" "createAdminClient() in feature code — belongs in Inngest step.run() or lib/ infrastructure; procedures use context.supabase under RLS"; done \
        < <(g1 'createAdminClient\(' "$f")
    done
  fi

  if rule_on service-role-exposure; then
    for f in "${TS[@]}"; do
      case "$f" in */inngest/*|*/lib/*|*/supabase/functions/*|*/scripts/*) continue ;; esac
      while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL service-role-exposure "$loc" "service-role key referenced in feature/app/component code — only lib/, inngest/ and edge functions may"; done \
        < <(grep -nE 'SUPABASE_SERVICE_ROLE|service_role|serviceRole' "$f" 2>/dev/null | grep -vE '^[0-9]+:[[:space:]]*(//|\*|/\*)' | cut -d: -f1 | sed "s|^|$f:|")
    done
  fi

  if rule_on sql-interpolation; then
    while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL sql-interpolation "$loc" "string interpolation in a SQL template — parameterize"; done \
      < <(g '(sql`[^`]*\$\{|\.(query|raw)\([[:space:]]*`[^`]*\$\{)' "${TS[@]}")
  fi

  if rule_on any-type; then
    while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL any-type "$loc" "any — use unknown, a Record, or the real type"; done \
      < <(g '(:[[:space:]]*any([^A-Za-z0-9_]|$)|<any>|[[:space:]]as[[:space:]]+any([^A-Za-z0-9_]|$))' "${TS[@]}")
    while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL any-type "$loc" "as unknown as — type the query (typed select or rpc) instead"; done \
      < <(g 'as[[:space:]]+unknown[[:space:]]+as[[:space:]]' "${TS[@]}")
    while IFS= read -r loc; do [ -n "$loc" ] && emit FAIL any-type "$loc" "@ts-ignore"; done \
      < <(g '@ts-ignore' "${TS[@]}")
  fi

  if rule_on ts-expect-error; then
    while IFS= read -r loc; do [ -n "$loc" ] && emit WARN ts-expect-error "$loc" "@ts-expect-error — say why on the same line"; done \
      < <(g '@ts-expect-error' "${TS[@]}")
  fi
  if rule_on eslint-disable; then
    while IFS= read -r loc; do [ -n "$loc" ] && emit WARN eslint-disable "$loc" "eslint-disable — fix the code or the rule"; done \
      < <(g 'eslint-disable' "${TS[@]}")
  fi
  if rule_on console-log; then
    for f in "${TS[@]}"; do
      case "$f" in */scripts/*|*/inngest/*|*/supabase/functions/*) continue ;; esac
      while IFS= read -r loc; do [ -n "$loc" ] && emit WARN console-log "$loc" "console.log in app code"; done \
        < <(g1 'console\.log\(' "$f")
    done
  fi

  MUT='(create|update|delete|remove|toggle|add|set|mark|archive|restore|reorder|upsert|bulk)'

  if rule_on actionable-missing; then
    # feature dirs in scope, from either layout: features/<f>/… or lib/orpc/procedures/<f>/…
    FEATS=$(for f in "${TS[@]}"; do echo "$f" | sed -nE 's|^(.*)/(features\|lib/orpc/procedures)/([^/]+)/.*|\1 \3|p'; done | sort -u)
    while read -r root feat; do
      [ -z "$feat" ] && continue
      case "$feat" in _shared|shared|index.ts) continue ;; esac
      procs=$(grep -rlE "export const ${MUT}[A-Za-z0-9_]*[[:space:]]*=" "$root/features/$feat" "$root/lib/orpc/procedures/$feat" 2>/dev/null | grep -v '/actions\.ts$' | grep -vE '\.(test|spec)\.' || true)
      [ -z "$procs" ] && continue
      # only mutation *procedures* count — the export must build a procedure
      real=""
      for p in $procs; do grep -qE '(protectedProcedure|paidProcedure|adminProcedure|publicProcedure|Procedure)' "$p" && real="$real $p"; done
      [ -z "$real" ] && continue
      act="$root/features/$feat/actions.ts"
      if [ ! -f "$act" ]; then
        emit FAIL actionable-missing "$act:0" "feature '$feat' has mutation procedures ($(echo $real | tr ' ' '\n' | head -1 | xargs basename)…) and no actions.ts — every mutation needs a .actionable() server action"
      elif ! grep -q '\.actionable(' "$act"; then
        emit FAIL actionable-missing "$act:1" "actions.ts exists but wraps nothing with .actionable()"
      fi
    done <<< "$FEATS"
  fi

  if rule_on secure-object-mutation; then
    for f in "${TS[@]}"; do
      case "$f" in */features/*|*/lib/orpc/*) ;; *) continue ;; esac
      grep -qE '(protectedProcedure|paidProcedure|adminProcedure)' "$f" || continue
      awk -v F="$f" -v MUT="$MUT" '
        $0 ~ ("export const " MUT "[A-Za-z0-9_]*[[:space:]]*=") { start=NR; name=$0; sub(/^export const /,"",name); sub(/[[:space:]]*=.*/,"",name) }
        start && NR-start<=8 && /\.input\([[:space:]]*z\.object\(/ { printf "%s:%d — %s uses z.object() for a mutation input; secureObject() drops unknown keys\n", F, NR, name; start=0 }
        start && NR-start>8 { start=0 }
      ' "$f" | while IFS= read -r line; do
        loc="${line%% — *}"; msg="${line#* — }"
        emit WARN secure-object-mutation "$loc" "$msg"
      done
    done
  fi
fi

# ─── SQL rules ───────────────────────────────────────────────────
if [ ${#SQL[@]} -gt 0 ]; then
  if rule_on definer-search-path; then
    for f in "${SQL[@]}"; do
      d=$(grep -ciE 'security[[:space:]]+definer' "$f" 2>/dev/null || true); d=${d:-0}
      s=$(grep -ciE 'set[[:space:]]+search_path' "$f" 2>/dev/null || true); s=${s:-0}
      if [ "$d" -gt "$s" ]; then
        line=$(grep -niE 'security[[:space:]]+definer' "$f" | head -1 | cut -d: -f1)
        emit FAIL definer-search-path "$f:$line" "$d SECURITY DEFINER function(s), $s with SET search_path — every definer sets search_path = ''"
      fi
    done
  fi
  if rule_on pii-trigger-log; then
    while IFS= read -r loc; do [ -n "$loc" ] && emit WARN pii-trigger-log "$loc" "to_jsonb(NEW/OLD) — if this table holds email/tokens/hashes, log ids only"; done \
      < <(g 'to_jsonb\((NEW|OLD)\)' "${SQL[@]}")
  fi
fi

# ─── Edge function / config rules ────────────────────────────────
if rule_on edge-cors-wildcard; then
  for f in "${TS[@]}"; do
    case "$f" in */supabase/functions/*) ;; *) continue ;; esac
    while IFS= read -r loc; do [ -n "$loc" ] && emit WARN edge-cors-wildcard "$loc" "wildcard CORS — allow the app origin only unless this function is public by design"; done \
      < <(g1 "Access-Control-Allow-Origin['\"]?[[:space:]]*:[[:space:]]*['\"]\*" "$f")
  done
fi
if rule_on edge-verify-jwt-off; then
  for f in "${TOML[@]}"; do
    while IFS= read -r loc; do [ -n "$loc" ] && emit WARN edge-verify-jwt-off "$loc" "verify_jwt = false — fine for a signed webhook, not for anything a user calls"; done \
      < <(g1 'verify_jwt[[:space:]]*=[[:space:]]*false' "$f")
  done
fi

# ─── CSS variable renames (index-aware, --staged only) ───────────
if [ "$STAGED" = "1" ] && rule_on css-var-rename; then
  for f in "${CSS[@]}"; do
    case "$f" in *globals.css|*tokens.css|*theme.css) ;; *) continue ;; esac
    removed=$(git diff --cached -U0 -- "$f" 2>/dev/null | grep -E '^-[[:space:]]*--[a-zA-Z0-9-]+:' | sed -E 's/^-[[:space:]]*(--[a-zA-Z0-9-]+):.*/\1/' | sort -u)
    [ -z "$removed" ] && continue
    added=$(git diff --cached -U0 -- "$f" 2>/dev/null | grep -E '^\+[[:space:]]*--[a-zA-Z0-9-]+:' | sed -E 's/^\+[[:space:]]*(--[a-zA-Z0-9-]+):.*/\1/' | sort -u)
    while IFS= read -r v; do
      [ -z "$v" ] && continue
      echo "$added" | grep -qx -- "$v" && continue
      emit FAIL css-var-rename "$f:0" "$v removed or renamed — change values, never names (every consumer breaks silently)"
    done <<< "$removed"
  done
fi

SUMMARY="LINT-PATTERNS: $NFAIL FAIL, $NWARN WARN (${#FILES[@]} files)"
[ -n "$RATCHET" ] && SUMMARY="$SUMMARY · $NPRE pre-existing not counted (ratchet vs $RATCHET)"
echo "$SUMMARY"
[ -n "$ADDED" ] && rm -f "$ADDED"
[ "$NFAIL" -gt 0 ] && exit 1
exit 0
