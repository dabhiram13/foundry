#!/usr/bin/env bash
#
# release-payload.sh — build (and optionally upload) the framework payload that
# the /cli-payload edge function serves to `buildthisnow init` and `update`.
#
# The npm tarball is the thin CLI only (bin/, lib/, scripts/, the two docs).
# Everything a customer actually installs — .claude/, .agents/, docs/, .githooks/,
# .codex/ and the managed root/scripts/CI files — travels in this payload. The
# same tarball is what `plugin-path` extracts for the Claude Code plugin, so
# .claude/.claude-plugin/plugin.json ships in it too. That makes
# this script, not .npmignore, the boundary between this repo's local session
# state and a stranger's machine. Read the exclusion list before changing it.
#
# Usage:
#   ./scripts/release-payload.sh --dry-run     # print exactly what would ship
#   ./scripts/release-payload.sh               # build dist/payload-<v>.tar.gz + sha256
#   ./scripts/release-payload.sh --publish     # build, then upload to Supabase Storage
#
# Environment (only needed for --publish; never echoed):
#   SUPABASE_URL                  https://<ref>.supabase.co
#   SUPABASE_SECRET_KEY           service-role key, for the Storage REST API
#   BUILDTHISNOW_PAYLOAD_BUCKET   Storage bucket the /cli-payload function signs
#
# The bucket name and the version table live inside the `cli-payload` edge
# function, which is NOT in this repo (see dev/active/harness-v2/phases/
# phase-0-provenance.md). Supply the bucket explicitly rather than guessing.
#
# Release checklist:
#   1. ./scripts/release-payload.sh --dry-run   and read the file list
#   2. ./scripts/release-payload.sh             and record the sha256
#   3. ./scripts/release-payload.sh --publish
#   4. run the `payload_versions` SQL the publish prints — that is what moves
#      `latest` to the new version + sha256 (--dry-run prints the same statements
#      with placeholders, so you can read them before building anything)
#   5. only THEN `npm publish`. Order matters: a 0.3.0 CLI against the 0.2.0
#      payload stops with "payload v0.2.0 has no .claude/.claude-plugin/plugin.json"
#      — every plugin install fails until `latest` points at a payload that
#      carries the plugin manifest.
#
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

MODE="build"
case "${1:-}" in
  --dry-run) MODE="dry-run" ;;
  --publish) MODE="publish" ;;
  "")        MODE="build" ;;
  *) echo "unknown argument: $1 (expected --dry-run, --publish, or nothing)" >&2; exit 2 ;;
esac

# Single source of truth for what ships: lib/constants.js.
VERSION=$(node -p "require('./lib/constants').VERSION")

# The oldest CLI that may install this payload. 0.3.0 is the first release whose
# `plugin-path` speaks the current /cli-payload handshake.
MIN_CLI="0.3.0"
# storage_path in payload_versions is stored bucket-prefixed; /cli-payload strips
# the prefix before signing.
DEFAULT_BUCKET="buildthisnow-payloads"

# The seller registers a new payload by hand — payload_versions is not in this
# repo. Print the exact two statements, so nobody has to reconstruct them from
# the sha256 scrolling past.
#   print_register_sql <storage_path> <sha256> <size_bytes>
print_register_sql() {
  cat <<SQL

-- Register payload v${VERSION} — run in the Supabase SQL editor:
update public.payload_versions set is_latest = false where is_latest;

insert into public.payload_versions
  (version, storage_path, sha256, size_bytes, is_latest, min_cli)
values
  ('${VERSION}', '$1', '$2', $3, true, '${MIN_CLI}');
SQL
}

# The plugin manifest travels inside the payload and is what Claude Code reads
# to name the installed version. If it disagrees with the CLI, customers see a
# version that does not exist. Fail before building, not after publishing.
PLUGIN_VERSION=$(node -p "require('./.claude/.claude-plugin/plugin.json').version")
if [ "$PLUGIN_VERSION" != "$VERSION" ]; then
  echo "release-payload: version mismatch —" >&2
  echo "  lib/constants.js VERSION              = $VERSION" >&2
  echo "  .claude/.claude-plugin/plugin.json    = $PLUGIN_VERSION" >&2
  echo "Set both to the same value before releasing." >&2
  exit 1
fi

MANAGED_TREES=$(node -p "require('./lib/constants').MANAGED_TREES.join('\n')")
MANAGED_FILES=$(node -p "require('./lib/constants').MANAGED_FILES.join('\n')")
PROTECTED=$(node -p "require('./lib/constants').PROTECTED_PATTERNS.join('\n')")

# CLAUDE.md is not installed by the CLI (/start composes the project's own from
# lib/templates/claude/*.md), but it rides in the payload so that every released
# version is a complete, recoverable snapshot of the harness.
EXTRA_FILES="CLAUDE.md"

# dev/, webapp/ and supabase/ are never inside a managed tree, so they cannot be
# swept in; they are listed here so a future widening of MANAGED_TREES trips
# this assertion instead of shipping them.
NEVER_SHIP="dev/ webapp/ supabase/ node_modules/ .git/"

is_protected() {
  local f="$1" p
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    case "$f/" in "$p"*) return 0 ;; esac
  done <<< "$PROTECTED"
  return 1
}

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
CANDIDATES="$TMP/candidates.txt"
LIST="$TMP/files.txt"
: > "$CANDIDATES"

while IFS= read -r tree; do
  [ -z "$tree" ] && continue
  if [ ! -d "$tree" ]; then
    echo "release-payload: missing managed tree $tree" >&2
    exit 1
  fi
  find "$tree" -type f -print >> "$CANDIDATES"
done <<< "$MANAGED_TREES"

while IFS= read -r file; do
  [ -z "$file" ] && continue
  if [ ! -f "$file" ]; then
    echo "release-payload: missing managed file $file" >&2
    exit 1
  fi
  printf '%s\n' "$file" >> "$CANDIDATES"
done <<< "$MANAGED_FILES"

for file in $EXTRA_FILES; do
  if [ ! -f "$file" ]; then
    echo "release-payload: missing $file" >&2
    exit 1
  fi
  printf '%s\n' "$file" >> "$CANDIDATES"
done

: > "$LIST"
while IFS= read -r f; do
  [ -z "$f" ] && continue
  case "$f" in
    */__pycache__/*|*.pyc|*.pyo|*.swp|*/.DS_Store|.DS_Store) continue ;;
    .claude/.manifest.json) continue ;;  # rebuilt below, added explicitly
  esac
  if is_protected "$f"; then continue; fi
  printf '%s\n' "$f" >> "$LIST"
done < "$CANDIDATES"

sort -u "$LIST" -o "$LIST"
COUNT=$(wc -l < "$LIST" | tr -d ' ')

# Assertion: nothing from a never-ship tree, and nothing protected, survived.
# Prefix matching via `case`, not grep — a pattern like `.claude/state/` is not
# a regex and must not be treated as one.
while IFS= read -r f; do
  [ -z "$f" ] && continue
  for bad in $NEVER_SHIP; do
    case "$f" in "$bad"*)
      echo "release-payload: refusing to ship — $f is under $bad" >&2
      exit 1 ;;
    esac
  done
  if is_protected "$f"; then
    echo "release-payload: refusing to ship — $f is a protected path" >&2
    exit 1
  fi
done < "$LIST"

if [ "$MODE" = "dry-run" ]; then
  echo "── payload v$VERSION — $COUNT file(s) ──"
  cat "$LIST"
  echo
  echo "manifest (.claude/.manifest.json) would be rebuilt first:"
  node scripts/build-manifest.js --dry-run | tail -1
  # Same statements a real --publish prints, with the two values only a build can
  # know left as placeholders.
  print_register_sql \
    "${BUILDTHISNOW_PAYLOAD_BUCKET:-$DEFAULT_BUCKET}/payload-${VERSION}.tar.gz" \
    "<sha256 — printed by a real build>" \
    "<size_bytes>"
  exit 0
fi

# 1. Rebuild the manifest so the payload describes itself.
node scripts/build-manifest.js
# The manifest is written into .claude/, so add it after the walk.
printf '%s\n' ".claude/.manifest.json" >> "$LIST"
sort -u "$LIST" -o "$LIST"

# 2. Tar it.
#    macOS bsdtar stores extended attributes (every file here carries
#    com.apple.provenance) as AppleDouble "._name" entries, and `tar -t` on
#    macOS hides them — so the archive looked clean while shipping one ghost
#    per file. Claude Code then loads "._backend.md" as an agent with no
#    frontmatter. COPYFILE_DISABLE + the two flags stop that at the source;
#    the check below fails the build if any slip through.
mkdir -p dist
TARBALL="dist/payload-${VERSION}.tar.gz"
rm -f "$TARBALL"
COPYFILE_DISABLE=1 tar --no-mac-metadata --no-xattrs -czf "$TARBALL" -T "$LIST"

if command -v python3 >/dev/null 2>&1; then
  GHOSTS=$(python3 - "$TARBALL" <<'PY'
import sys, tarfile
names = [m.name for m in tarfile.open(sys.argv[1]).getmembers()]
print(sum(1 for n in names if n.rsplit('/', 1)[-1].startswith('._') or n.endswith('/.DS_Store')))
PY
)
  if [ "$GHOSTS" != "0" ]; then
    echo "release-payload: $GHOSTS AppleDouble/.DS_Store entries in $TARBALL — refusing to ship" >&2
    exit 1
  fi
fi

SHA=$(shasum -a 256 "$TARBALL" | awk '{print $1}')
SIZE=$(wc -c < "$TARBALL" | tr -d ' ')
echo "built  $TARBALL"
echo "files  $(wc -l < "$LIST" | tr -d ' ')"
echo "bytes  $SIZE"
echo "sha256 $SHA"

if [ "$MODE" != "publish" ]; then
  echo
  echo "not uploaded. Re-run with --publish once the file list above is what you want."
  exit 0
fi

# 3. Upload.
: "${SUPABASE_URL:?SUPABASE_URL is required for --publish}"
: "${SUPABASE_SECRET_KEY:?SUPABASE_SECRET_KEY is required for --publish}"
: "${BUILDTHISNOW_PAYLOAD_BUCKET:?BUILDTHISNOW_PAYLOAD_BUCKET is required for --publish}"

OBJECT="payload-${VERSION}.tar.gz"
UPLOAD_URL="${SUPABASE_URL}/storage/v1/object/${BUILDTHISNOW_PAYLOAD_BUCKET}/${OBJECT}"
echo "uploading to ${BUILDTHISNOW_PAYLOAD_BUCKET}/${OBJECT}"

RESPONSE=$(curl -s -w "\n%{http_code}" \
  -X POST \
  -H "apikey: ${SUPABASE_SECRET_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_SECRET_KEY}" \
  -H "Content-Type: application/gzip" \
  -H "x-upsert: true" \
  --data-binary "@${TARBALL}" \
  "${UPLOAD_URL}")

HTTP_STATUS=$(echo "$RESPONSE" | tail -1)
BODY=$(echo "$RESPONSE" | sed '$d')

if [ "$HTTP_STATUS" = "200" ] || [ "$HTTP_STATUS" = "201" ]; then
  echo "uploaded:"
  echo "  version ${VERSION}"
  echo "  object  ${BUILDTHISNOW_PAYLOAD_BUCKET}/${OBJECT}"
  echo "  sha256  ${SHA}"
  # The upload alone changes nothing customers see: /cli-payload serves whatever
  # row is is_latest. This is the statement that flips it.
  print_register_sql "${BUILDTHISNOW_PAYLOAD_BUCKET}/${OBJECT}" "${SHA}" "${SIZE}"
else
  echo "upload failed with HTTP $HTTP_STATUS" >&2
  echo "$BODY" >&2
  exit 1
fi
