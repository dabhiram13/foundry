#!/usr/bin/env bash
set -euo pipefail

# send-report-email.sh — Send a report email via Resend API
# Usage: send-report-email.sh "<subject>" <report-file>
# Fails silently if RESEND_API_KEY or ADMIN_EMAIL are not set.

SUBJECT="${1:?Usage: send-report-email.sh \"<subject>\" <report-file>}"
REPORT_FILE="${2:?Usage: send-report-email.sh \"<subject>\" <report-file>}"

# --- Load env from webapp/.env ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$PROJECT_DIR/webapp/.env"

if [ -f "$ENV_FILE" ]; then
  # Source only the keys we need (handles quoted and unquoted values)
  RESEND_API_KEY="${RESEND_API_KEY:-$(grep -E '^RESEND_API_KEY=' "$ENV_FILE" | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'" || true)}"
  ADMIN_EMAIL="${ADMIN_EMAIL:-$(grep -E '^ADMIN_EMAIL=' "$ENV_FILE" | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'" || true)}"
  EMAIL_FROM="${EMAIL_FROM:-$(grep -E '^EMAIL_FROM=' "$ENV_FILE" | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'" || true)}"
fi

# --- Exit if missing config (exit 0 so it doesn't fail the report, but log clearly) ---
MISSING=""
if [ -z "${RESEND_API_KEY:-}" ]; then MISSING="RESEND_API_KEY"; fi
if [ -z "${ADMIN_EMAIL:-}" ]; then MISSING="${MISSING:+$MISSING, }ADMIN_EMAIL"; fi

if [ -n "$MISSING" ]; then
  echo "[send-report-email] SKIPPED — missing env vars: $MISSING"
  echo "[send-report-email] Set them in webapp/.env or run: speedy → Settings → Environment"
  exit 0
fi

FROM="${EMAIL_FROM:-Build Kit <onboarding@resend.dev>}"

# --- Read report file ---
if [ ! -f "$REPORT_FILE" ]; then
  echo "[send-report-email] Report file not found: $REPORT_FILE — skipping email"
  exit 0
fi

BODY=$(cat "$REPORT_FILE")

# --- Build plain text + simple HTML ---
# Escape for JSON
TEXT_ESCAPED=$(printf '%s' "$BODY" | jq -Rs .)
HTML_BODY=$(printf '%s' "$BODY" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/$/<br>/g')
HTML_ESCAPED=$(printf '%s' "<div style=\"font-family: monospace; font-size: 13px; line-height: 1.6; padding: 24px;\">$HTML_BODY</div>" | jq -Rs .)

# --- Send via Resend API ---
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "https://api.resend.com/emails" \
  -H "Authorization: Bearer $RESEND_API_KEY" \
  -H "Content-Type: application/json" \
  -d "$(jq -n \
    --arg from "$FROM" \
    --arg to "$ADMIN_EMAIL" \
    --arg subject "$SUBJECT" \
    --argjson html "$HTML_ESCAPED" \
    --argjson text "$TEXT_ESCAPED" \
    '{from: $from, to: [$to], subject: $subject, html: $html, text: $text}'
  )")

HTTP_CODE=$(echo "$RESPONSE" | tail -1)
RESPONSE_BODY=$(echo "$RESPONSE" | sed '$d')

if [ "$HTTP_CODE" -ge 200 ] && [ "$HTTP_CODE" -lt 300 ]; then
  EMAIL_ID=$(echo "$RESPONSE_BODY" | jq -r '.id // "unknown"')
  echo "[send-report-email] Sent: $EMAIL_ID"
else
  echo "[send-report-email] Failed (HTTP $HTTP_CODE): $RESPONSE_BODY"
  # Fail silently — email is nice-to-have
  exit 0
fi
