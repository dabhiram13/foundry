#!/usr/bin/env bash
# verify.sh — the one check, three homes.
#
#   .githooks/pre-commit          → verify.sh --staged    guarantee: cannot be talked past
#   .github/workflows/verify.yml  → verify.sh --all       guarantee: CI
#   .claude/hooks/verify-stop.sh  → verify.sh --changed   accelerator: 30 s after the mistake
#
# Steps, in order: malware-scan · harness-sync · patterns · typecheck · lint · tests · build
#   --staged   staged app files only. patterns + typecheck + lint. No tests, no build.
#   --changed  files changed vs HEAD. patterns + typecheck + lint + unit tests. No build.
#              Both exit early when no app-code file is in scope, so a commit that
#              touches only .claude/ does not reach harness-sync — CI's --all does.
#   --all      everything. All steps; build unless --no-build / VERIFY_SKIP_BUILD=1.
#
# Flags:  --no-build  --no-tests  --quiet  --print-app-dir
# Env:    VERIFY_APP_DIR=<dir>   VERIFY_SKIP_BUILD=1   VERIFY_SKIP_TESTS=1
#         VERIFY_BASE=<ref>  ratchet base for --all patterns (default: origin/main when it exists)
#
# Patterns are a line-level ratchet and lint a file-level one: only what you touch is gated
# (index for --staged, HEAD for --changed, VERIFY_BASE for --all). Pre-existing findings are
# counted, reported once as debt in .claude/state/verify-debt.txt, and never block.
# typecheck / tests / build are whole-tree — a partial typecheck is not one.
#
# Output: one "STEP <name>: PASS|FAIL|SKIP (reason)" line per step, the tail of any
#         failing step, then "VERIFY: PASS|FAIL — <steps>". Exit 1 on FAIL.
#         Also written to .claude/state/verify-last.json when .claude/ exists.
#
# A step that cannot run (no node_modules, no tsc) is a FAIL, not a skip:
# missing evidence is not a pass.

# (no set -u: empty-array expansion is an error under macOS bash 3.2)

MODE=""
NO_BUILD="${VERIFY_SKIP_BUILD:-0}"
NO_TESTS="${VERIFY_SKIP_TESTS:-0}"
QUIET=0
PRINT_APP=0
for a in "$@"; do
  case "$a" in
    --staged|--changed|--all) MODE="${a#--}" ;;
    --no-build) NO_BUILD=1 ;;
    --no-tests) NO_TESTS=1 ;;
    --quiet) QUIET=1 ;;
    --print-app-dir) PRINT_APP=1 ;;
    -h|--help) sed -n '2,24p' "$0"; exit 0 ;;
    *) echo "verify: unknown flag $a" >&2; exit 2 ;;
  esac
done

ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
cd "$ROOT" || exit 2
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Locate the app ──────────────────────────────────────────────
APP=""
if [ -n "${VERIFY_APP_DIR:-}" ] && [ -f "${VERIFY_APP_DIR}/package.json" ]; then
  APP="${VERIFY_APP_DIR%/}"
elif [ -f webapp/package.json ]; then
  APP="webapp"
elif [ -f package.json ] && grep -qE '"next"[[:space:]]*:' package.json 2>/dev/null; then
  APP="."
fi

if [ "$PRINT_APP" = "1" ]; then
  echo "$APP"
  exit 0
fi

if [ -z "$MODE" ]; then
  echo "verify: pick a mode — --staged, --changed or --all (see --help)" >&2
  exit 2
fi

if [ -z "$APP" ]; then
  echo "VERIFY: PASS — no app to verify (no webapp/package.json and no Next app at the root)"
  exit 0
fi

# ─── Scope ───────────────────────────────────────────────────────
is_code() {
  case "$1" in
    *.ts|*.tsx|*.js|*.jsx|*.mjs|*.cjs|*.sql|*.toml|*.css) return 0 ;;
    *) return 1 ;;
  esac
}
SCOPE=()   # repo-relative paths, code files only
SCOPE_DIRS=("$APP")
[ -d supabase ] && [ "$APP" != "." ] && SCOPE_DIRS+=("supabase")

case "$MODE" in
  staged)
    while IFS= read -r f; do [ -n "$f" ] && is_code "$f" && [ -f "$f" ] && SCOPE+=("$f"); done \
      < <(git diff --cached --name-only --diff-filter=ACMR -- "${SCOPE_DIRS[@]}" 2>/dev/null)
    ;;
  changed)
    while IFS= read -r f; do [ -n "$f" ] && is_code "$f" && [ -f "$f" ] && SCOPE+=("$f"); done \
      < <({ git diff --name-only HEAD -- "${SCOPE_DIRS[@]}"; git ls-files --others --exclude-standard -- "${SCOPE_DIRS[@]}"; } 2>/dev/null | sort -u)
    ;;
  all) ;;
esac

if [ "$MODE" != "all" ] && [ ${#SCOPE[@]} -eq 0 ]; then
  echo "VERIFY: PASS — nothing in scope (--$MODE: no app code files)"
  exit 0
fi

# ─── Step runner ─────────────────────────────────────────────────
RESULTS=()
FAILED=0
LOGDIR=$(mktemp -d 2>/dev/null || echo "/tmp/verify-$$")
mkdir -p "$LOGDIR"

step() { # name  cmd...   (runs in $ROOT)
  local name="$1"; shift
  local log="$LOGDIR/$name.log" start end rc n
  start=$(date +%s)
  ( "$@" ) >"$log" 2>&1
  rc=$?
  end=$(date +%s)
  n=40; [ "$name" = "patterns" ] && n=${PATTERNS_TAIL:-80}
  if [ $rc -eq 0 ]; then
    RESULTS+=("$name:PASS")
    [ "$QUIET" = "1" ] || echo "STEP $name: PASS ($((end-start))s)$([ "$name" = "patterns" ] && echo " — $(tail -1 "$log")")"
  else
    RESULTS+=("$name:FAIL")
    FAILED=1
    echo "STEP $name: FAIL ($((end-start))s, exit $rc)"
    echo "----- $name (last $n lines) -----"
    tail -n "$n" "$log"
    echo "-----"
  fi
  return $rc
}
skip() { RESULTS+=("$1:SKIP"); [ "$QUIET" = "1" ] || echo "STEP $1: SKIP ($2)"; }

in_app() { ( cd "$APP" && "$@" ); }
has_any() { local f; for f in "$@"; do [ -e "$f" ] && return 0; done; return 1; }

# Paths relative to the app dir, for eslint on a subset
app_rel() {
  local f
  for f in "$@"; do
    case "$f" in
      "$APP"/*) echo "${f#"$APP"/}" ;;
      *) [ "$APP" = "." ] && echo "$f" ;;
    esac
  done
}

# ─── 0. malware scan (the May-2026 guard; before anything executes) ─
if [ -f "$APP/scripts/scan-malware.mjs" ]; then
  step malware-scan node "$APP/scripts/scan-malware.mjs" .
else
  skip malware-scan "no scan-malware.mjs"
fi

# ─── 0b. harness sync (.agents/ is generated from .claude/) ───────
# Only in this repo: a customer project has neither the generator nor .agents/
# built from source, so the check has nothing to compare and SKIPs.
if [ -f "$HERE/gen-agents.sh" ] && [ -d "$ROOT/.agents" ]; then
  step harness-sync bash "$HERE/gen-agents.sh" --check --root "$ROOT"
elif [ ! -f "$HERE/gen-agents.sh" ]; then
  skip harness-sync "no scripts/gen-agents.sh"
else
  skip harness-sync "no .agents/"
fi

# ─── 1. patterns (ratchet) ───────────────────────────────────────
PATTERNS_TAIL=80
BASE=""
if [ "$MODE" = "all" ]; then
  BASE="${VERIFY_BASE:-}"
  if [ -z "$BASE" ] && git rev-parse -q --verify origin/main >/dev/null 2>&1; then BASE="origin/main"; fi
  git rev-parse -q --verify "$BASE" >/dev/null 2>&1 || BASE=""
  if [ -n "$BASE" ]; then
    step patterns bash "$HERE/lint-patterns.sh" --diff-base "$BASE" "${SCOPE_DIRS[@]}"
    # whole-tree debt, reported, never blocking
    if [ -d .claude ]; then
      mkdir -p .claude/state
      bash "$HERE/lint-patterns.sh" --warn-only "${SCOPE_DIRS[@]}" > .claude/state/verify-debt.txt 2>/dev/null
      [ "$QUIET" = "1" ] || echo "      debt (whole tree, not blocking): $(tail -1 .claude/state/verify-debt.txt | sed 's/LINT-PATTERNS: //; s/ FAIL,/ findings,/') → .claude/state/verify-debt.txt"
    fi
    # files changed since the base become the lint scope below (file-level ratchet)
    while IFS= read -r f; do [ -n "$f" ] && is_code "$f" && [ -f "$f" ] && SCOPE+=("$f"); done \
      < <({ git diff --name-only "$BASE" -- "${SCOPE_DIRS[@]}"; git ls-files --others --exclude-standard -- "${SCOPE_DIRS[@]}"; } 2>/dev/null | sort -u)
  else
    step patterns bash "$HERE/lint-patterns.sh" "${SCOPE_DIRS[@]}"
  fi
elif [ "$MODE" = "staged" ]; then
  step patterns bash "$HERE/lint-patterns.sh" --staged --files "${SCOPE[@]}"
else
  step patterns bash "$HERE/lint-patterns.sh" --diff-base HEAD --files "${SCOPE[@]}"
fi

# ─── 2. typecheck (always project-wide — a partial typecheck is not one) ─
if [ ! -d "$APP/node_modules" ]; then
  echo "STEP typecheck: FAIL (no $APP/node_modules — run npm install; a check that cannot run is not a pass)"
  RESULTS+=("typecheck:FAIL"); FAILED=1
  TSC_OK=0
elif [ -f "$APP/tsconfig.json" ]; then
  step typecheck in_app npx --no-install tsc --noEmit -p tsconfig.json
  TSC_OK=$?; [ $TSC_OK -eq 0 ] && TSC_OK=1 || TSC_OK=0
else
  skip typecheck "no tsconfig.json"; TSC_OK=1
fi

# ─── 3. lint ─────────────────────────────────────────────────────
if [ ! -d "$APP/node_modules" ]; then
  RESULTS+=("lint:FAIL"); FAILED=1
  echo "STEP lint: FAIL (no $APP/node_modules)"
elif has_any "$APP"/eslint.config.* "$APP"/.eslintrc*; then
  if [ "$MODE" = "all" ] && [ -z "$BASE" ]; then
    step lint in_app npx --no-install eslint .
  else
    if [ "$MODE" = "all" ] && [ -d .claude ]; then
      # whole-tree lint debt, reported, never blocking
      # ESLint 9 dropped the unix/compact formatters — count errors from the JSON formatter
      DEBT_LINT=$(in_app npx --no-install eslint . -f json 2>/dev/null | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{console.log(JSON.parse(s).reduce((n,f)=>n+f.errorCount,0))}catch{console.log("?")}})' 2>/dev/null || echo "?")
      { echo; echo "ESLINT (whole tree, not blocking): ${DEBT_LINT:-0} errors"; } >> .claude/state/verify-debt.txt 2>/dev/null
      [ "$QUIET" = "1" ] || echo "      eslint debt (whole tree, not blocking): ${DEBT_LINT:-0} errors"
    fi
    LINT_FILES=()
    while IFS= read -r f; do
      case "$f" in *.ts|*.tsx|*.js|*.jsx|*.mjs|*.cjs) LINT_FILES+=("$f") ;; esac
    done < <(app_rel "${SCOPE[@]}")
    if [ ${#LINT_FILES[@]} -gt 0 ]; then
      step lint in_app npx --no-install eslint "${LINT_FILES[@]}"
    else
      skip lint "no JS/TS files in scope"
    fi
  fi
else
  skip lint "no eslint config"
fi

# ─── 4. tests (unit — the frozen set; e2e is the testers' job) ────
if [ "$MODE" = "staged" ] || [ "$NO_TESTS" = "1" ]; then
  skip tests "$([ "$MODE" = "staged" ] && echo 'not at pre-commit' || echo 'VERIFY_SKIP_TESTS')"
elif [ ! -d "$APP/node_modules" ]; then
  RESULTS+=("tests:FAIL"); FAILED=1
  echo "STEP tests: FAIL (no $APP/node_modules)"
elif grep -qE '"test:unit"[[:space:]]*:' "$APP/package.json" 2>/dev/null; then
  step tests in_app npm run --silent test:unit
elif has_any "$APP"/vitest.config.*; then
  step tests in_app npx --no-install vitest run --exclude 'tests/e2e/**'
else
  skip tests "no unit test runner"
fi

# ─── 5. build ────────────────────────────────────────────────────
if [ "$MODE" != "all" ]; then
  skip build "only in --all"
elif [ "$NO_BUILD" = "1" ]; then
  skip build "--no-build / VERIFY_SKIP_BUILD"
elif [ "$TSC_OK" = "0" ]; then
  skip build "typecheck failed"
elif [ ! -d "$APP/node_modules" ]; then
  RESULTS+=("build:FAIL"); FAILED=1
  echo "STEP build: FAIL (no $APP/node_modules)"
else
  step build in_app npm run --silent build
fi

# ─── Summary ─────────────────────────────────────────────────────
SUMMARY=$(printf '%s ' "${RESULTS[@]}")
if [ "$FAILED" = "1" ]; then
  echo "VERIFY: FAIL — ${SUMMARY% }"
  VERDICT=FAIL
else
  echo "VERIFY: PASS — ${SUMMARY% }"
  VERDICT=PASS
fi

if [ -d .claude ]; then
  mkdir -p .claude/state
  {
    printf '{"verdict":"%s","mode":"%s","app":"%s","ts":"%s","steps":{' "$VERDICT" "$MODE" "$APP" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    first=1
    for r in "${RESULTS[@]}"; do
      [ "$first" = "1" ] || printf ','
      first=0
      printf '"%s":"%s"' "${r%%:*}" "${r#*:}"
    done
    printf '}}\n'
  } > .claude/state/verify-last.json 2>/dev/null
fi

rm -rf "$LOGDIR" 2>/dev/null
[ "$FAILED" = "1" ] && exit 1
exit 0
