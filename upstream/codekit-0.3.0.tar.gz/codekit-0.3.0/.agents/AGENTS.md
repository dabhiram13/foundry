# Codex Ops System

This `.agents` tree holds the Codex-native ops workflows. The Claude commands themselves are generated into `.agents/skills/codekit-*/` by `scripts/gen-agents.sh` — see `PORTING.md`.

Scope:
- Do not modify `.claude/`
- Use Codex automations plus `.agents` skills as the execution layer
- Treat reports, fix loops, and summaries as separate responsibilities

Core design:
- `monitor` detects and summarizes
- `heal` fixes on a dedicated branch or worktree
- `security-review` handles code and app risk detection
- The reporting agent never owns the fix implementation

Operational rules:
- Never push directly to `main`
- Prefer a dedicated fix branch or worktree for remediation
- Create or update Linear issues for anything that is not trivially auto-fixable
- Keep GitHub as the source of truth for code changes and PRs
- Keep Vercel and Sentry as production/runtime signal sources
- Use email only for digesting or escalation, not as the primary workflow database

Recommended daily loop:
1. Collect signals from Sentry, Vercel, GitHub, Linear, and project reports
2. Produce a concise operating summary with severity and owner/action
3. Open or update Linear issues for actionable items
4. If a critical/high issue is fixable, create a branch/worktree and delegate remediation
5. Run verification gates
6. Report outcome and any remaining risk

Directory contract:
- `.agents/skills/codex-monitor/` holds detection/orchestration guidance
- `.agents/skills/codex-heal/` holds remediation guidance
- `.agents/skills/codex-security-review/` holds security-focused audit guidance
- `.agents/automations/` holds reusable Codex automation prompt specs
- `.agents/workflows/` holds cross-skill operating procedures
