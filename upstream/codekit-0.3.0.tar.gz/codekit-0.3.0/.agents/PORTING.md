# `.agents/` and `.codex/` — what they are and who writes them

`.claude/` is the source of truth. `.agents/` and `.codex/` are **generated targets** for Codex,
Copilot and anything else that reads them — plus a small hand-owned, Codex-only remainder the
generator never writes and never deletes. A smaller SKU with its own honest feature list, not a peer.

Regenerate with:

```bash
bash scripts/gen-agents.sh            # write .agents/ + .codex/
bash scripts/gen-agents.sh --check    # no writes; exit 1 and print the drift
```

`scripts/verify.sh` runs `--check` as its `harness-sync` step, so drift cannot be committed.

## What Codex actually reads

Verified against `codex-cli 0.149.1` and `learn.chatgpt.com/docs` on 2026-08-30.

| Codex reads | Where it looks | Where it comes from here | Owner |
|---|---|---|---|
| Skills | `<repo>/.agents/skills/<name>/SKILL.md` (walks **up** from cwd), `.codex/skills/`, `~/.codex/skills/`, `~/.agents/skills/` | `.claude/skills/<name>/` (60) and `.claude/commands/<cmd>.md` → `codekit-<cmd>` (34) | generated |
| Instructions | repo-root `AGENTS.md`, then per-directory `AGENTS.md` / `AGENTS.override.md` down to cwd, 32 KiB total. **No `@file` imports. `.agents/AGENTS.md` is not read.** | the repo-root `AGENTS.md` | hand-owned |
| Subagents | `.codex/agents/<name>.toml` — `name`, `description`, `developer_instructions` required; `model`, `model_reasoning_effort`, `sandbox_mode`, `mcp_servers`, `skills.config` optional. Inline strings only. | `.claude/agents/<name>.md` (28) | generated |
| Hooks (GA, on by default) | `.codex/hooks.json` — Claude's JSON shape; events `SessionStart PermissionRequest PreToolUse PostToolUse PreCompact PostCompact SessionEnd UserPromptSubmit SubagentStart SubagentStop Stop`; stdin carries `agent_type`, `tool_name`, `tool_input.command`, `prompt`; stdout `hookSpecificOutput.additionalContext`, `permissionDecision`, `decision: "block"`. cwd = session cwd | a template inside `scripts/gen-agents.sh` that mirrors `.claude/hooks/hooks.json` | generated |
| Project config | `.codex/config.toml` — `[mcp_servers.*]`, `[[skills.config]]` | `.mcp.json` | generated |
| Slash commands | any skill with `user-invocable: true` shows up as `$name`; `argument-hint`, `$ARGUMENTS` and `disable-model-invocation` are recognised, unknown frontmatter keys tolerated | the 34 `codekit-<cmd>` skills | generated |
| Plugins (GA) | `.codex-plugin/plugin.json` (the loader also accepts `.claude-plugin/plugin.json`); marketplaces at `.agents/plugins/marketplace.json` | not built — see Open | — |
| Automations | app UI only, server-side; **no repo file format exists** | `.agents/automations/*.md` are prompt text for a human to paste | hand-owned |

**Trust step.** Hooks and `.codex/config.toml` are honoured in trusted projects only, and the user
reviews the hook list once via `/hooks` before any of it runs. A fresh clone runs no codekit hook
under Codex until someone does that.

Not read by Codex, and therefore no longer generated: `.agents/agents/`, `.agents/commands/`.
Still generated, as on-disk references the generated skills and agents point at: `.agents/docs/`,
`.agents/philosophy/`, `.agents/PROMPT.md`, `.agents/reference/claude-settings.json`.

Other harnesses reading `.agents/skills/` today: Copilot (also `.claude/skills`), Cursor (also
`.claude/skills`), Gemini CLI (not `.claude/skills`), opencode, Amp. `.agents/skills/` is a
convention recommended by the Agent Skills client guide, not a normative path — six harnesses is the
fact that matters.

## Generated — do not edit

Editing any of these loses the edit on the next run. Edit the `.claude/` original instead.
`.agents/.generated` is the manifest: one repo-relative path per line, `LC_ALL=C` sorted, written by
the last run, covering both `.agents/…` and `.codex/…`. It is also the delete list — the generator
removes exactly what it wrote before, and never `rm -rf .agents/`.

| Generated | From |
|---|---|
| `.codex/agents/<name>.toml` | `.claude/agents/<name>.md` |
| `.agents/skills/codekit-<cmd>/SKILL.md` | `.claude/commands/<cmd>.md` |
| `.agents/skills/<name>/` | `.claude/skills/<name>/` — one per `.claude` skill |
| `.agents/docs/` | `.claude/docs/` |
| `.agents/philosophy/` | `.claude/philosophy/` |
| `.agents/PROMPT.md` | `.claude/PROMPT.md` |
| `.agents/reference/claude-settings.json` | `.claude/settings.json`, verbatim |
| `.codex/hooks.json` | a template in `scripts/gen-agents.sh`, mirroring `.claude/hooks/hooks.json` |
| `.codex/config.toml` | `.mcp.json` |

### The agent TOMLs

Keys, in this order: `name`, `description`, `model_reasoning_effort` (only when the source has
`effort:` ∈ `low|medium|high|xhigh|max`), `sandbox_mode`, `developer_instructions`.
`sandbox_mode` is `"read-only"` when `disallowedTools:` names both Write and Edit, or when `tools:`
is set and names neither; otherwise `"workspace-write"`.

`model`, `mcp_servers`, `tools`, `maxTurns`, `skills`, `philosophy`, `permissionMode` and `effort`
are **never** emitted: the Claude model names are not Codex model names, and the rest have no Codex
equivalent that would be honest.

`developer_instructions` is the agent body (frontmatter stripped, rewritten) plus up to three
generated read-lists — `## Philosophy`, `## Skills`, `## MCP` — naming files instead of inlining
them. `.codex/hooks.json` registers `subagent-prime.sh` on `SubagentStart`, which injects the same
philosophy and skills when Codex reports `agent_type`; the read-lists are the fallback for when it
does not (see Open).

### The command skills

Frontmatter: `name: codekit-<cmd>`, `description:` (the command's, else its first `# ` heading text,
else `codekit /<cmd>`), `argument-hint:` only when the source has one, `user-invocable: true`,
`disable-model-invocation: true`. The generator dies if a `.claude/skills/codekit-<cmd>` ever appears
and fights for the same directory.

### Rewrites

Applied to generated `*.md` and to `developer_instructions` only — every other file is copied
byte-for-byte, so a skill's scripts and JSON fixtures are never touched.

- Named files first, so nothing is rewritten twice: `.claude/agents/<n>.md` → `.codex/agents/<n>.toml`,
  `.claude/commands/<c>.md` → `.agents/skills/codekit-<c>/SKILL.md`.
- Then directories, and only the prefixes that exist in a generated tree: `.claude/agents/` →
  `.codex/agents/`, `.claude/commands/` → `.agents/skills/`, `.claude/docs/`, `.claude/philosophy/`,
  `.claude/skills/`, `.claude/PROMPT.md`. Everything else under `.claude/` — `hooks/`, `state/`,
  `settings.json`, `workflows/`, `migrations/`, `memory-seed/`, `.build-active.json` — has no
  generated counterpart and keeps pointing at the real file. A blanket `.claude/` → `.agents/` makes
  the generated evaluators tell Codex to run `.agents/hooks/verdict-gate.py`, which does not exist.
- `~/.claude/` and `$HOME/.claude/` are left alone: those name Claude Code's own home directory, not
  a path in this repo.
- `CLAUDE.md` → `AGENTS.md`.
- Command bodies, agent bodies and `PROMPT.md` also take the Codex vocabulary: `/<cmd>` →
  `$codekit-<cmd>` for the 34 command names (only when the character before is start-of-line or
  outside `[/A-Za-z0-9._-]` and the character after is end-of-line or outside `[A-Za-z0-9_-]`, so
  `docs/setup-links.md` survives intact), `.claude/scripts/` → `.agents/scripts/`, `claude-monitor` →
  `codex-monitor` (so `.claude/scripts/claude-monitor-run.sh` becomes
  `.agents/scripts/codex-monitor-run.sh`), and `Claude Code` → `Codex`.

## Hand-owned, Codex-only

The generator never writes and never deletes these:

- `AGENTS.md` — the Codex ops system doc. (The shared rules live in the repo-root `AGENTS.md`, which
  Codex reads natively; this one it does not read, so treat it as documentation for humans.)
- `PORTING.md` — this file.
- `automations/` — three Codex automation prompt specs (`daily-ops-summary.md`, `nightly-heal.md`,
  `README.md`), prompt text for a human to paste into the app UI.
- `scripts/codex-monitor-run.sh` — the scheduled runner the generated `codekit-monitor` skill calls.
- `workflows/` — three cross-skill operating procedures (`autonomous-ops.md`,
  `digital-product-template-contract.md`, `digital-product-template-spec.md`). Zero filename overlap
  with `.claude/workflows/`; these are Codex-native, not a port.
- `react-doctor/`.
- Every `.agents/skills/<name>` with no `.claude/skills/<name>` and no `.claude/commands/<name minus
  codekit->` counterpart — 7 today, all Codex-only by design. See "Known debt".

## Important limitation

Claude hook registration is not automatically honoured by Codex. `.codex/hooks.json` now carries the
same 14 registrations, but they are inert until the project is trusted and the user approves the
list via `/hooks`. Where that is not available, Codex wiring is still:

- automations
- AGENTS rules
- explicit CLI entrypoints

`.agents/hooks/` used to hold a copy of `.claude/hooks/`. It was deleted: nothing executed it, and it
had already fallen six scripts and a whole `dream/` subtree behind the originals. The generated
`.codex/hooks.json` points at `.claude/hooks/<x>` directly rather than at a second copy, so there is
nothing to drift. `scripts/verify.sh` is the part that is portable, and it runs identically under any
harness.

## Known debt

**Codex-only, by design.** Seven `.agents/skills/<name>` directories have no `.claude/skills/`
counterpart and are not meant to get one:

| Skill | Why it stays |
|---|---|
| `codex-heal` | Codex-native remediation loop; `.agents/AGENTS.md:34` points at it. The Claude side is `/heal`. |
| `codex-monitor` | Codex-native ops summary; `.agents/AGENTS.md:33` points at it. The Claude side is `/monitor`. |
| `codex-security-review` | Codex-native audit flow; `.agents/AGENTS.md:35` points at it. The Claude side is `/security`. |
| `ralph-tui-prd` | PRD generator for the third-party `ralph-tui` autonomous loop. |
| `ralph-tui-create-beads` | PRD → beads (`bd` CLI) for `ralph-tui`. |
| `ralph-tui-create-beads-rust` | Same, for the beads-rust (`br`) CLI. |
| `ralph-tui-create-json` | PRD → `prd.json` for `ralph-tui`. |

The four `ralph-tui-*` bundles are the weaker half of that list: `grep -rn "ralph-tui"` finds them in
each other, in this file and in `dev/`, and in nothing else — not `.agents/AGENTS.md`, not
`automations/`, not `workflows/`, not `.claude/`. They are kept as a Codex-side bet on the
`ralph-tui` loop; whoever owns the Codex surface should either wire them into `automations/` or
delete them.

**`.agents/AGENTS.md` still describes the old shape.** It says the tree replaces
`.claude/commands/`; the replacement is now `.agents/skills/codekit-*`. It is hand-owned and Codex
does not read it, so it is documentation debt, not a broken path.

**Closed in Phase 8d.** The 27 bundles that predated the direction reversal are gone: 15 were
byte-identical duplicates of content Phase 8 had already folded into `.claude/skills/*/references/`
(the six `inngest-*`, `firecrawl` + `firecrawl-crawl`, `a11y-debugging`, `chrome-devtools`,
`debug-optimize-lcp`, `next-cache-components`, `next-upgrade`, `vercel-cli`,
`vercel-cli-with-tokens`); 5 were deleted outright (`browser-use`, `playwright-cli`,
`e2e-testing-patterns`, `jest-react-testing`, `logo-design-guide`); `blog-writer` and `nextjs-seo`
became top-level `.claude/skills/`; `project-discovery` became
`.claude/skills/discover/references/project-discovery/`. Every `.claude/` reference to them was
repointed at what exists, so a Claude-only install resolves.

## Open — deliberately

- **`agent_type` for custom Codex agents.** The docs say `SubagentStart` carries `agent_type` and
  that matchers match "agent type"; whether that equals the TOML `name` is unverified. Test: a
  `SubagentStart` hook that appends `$agent_type` to a file, spawn `planner`, read the file. Until
  then the read-lists in `developer_instructions` are the guarantee.
- **The Codex skill index budget.** Codex lists skill names and descriptions in ≤ 2 % of context
  (8,000 chars when unknown) and truncates descriptions first; 60 + 34 + 7 entries may exceed it.
  `disable-model-invocation: true` on the 34 command skills is meant to keep them out of the model's
  list — unverified for Codex. If descriptions come back truncated, that is the first knob.
- **A Codex plugin / marketplace.** The manifest schema is documented; the licence gate is not (no
  `command` source, no headers). The Codex SKU is delivered by `npx buildthisnow init`, which
  installs `.agents/` and `.codex/` into the project — no plugin needed for Codex to read them.
- **Windows.** Hook scripts are bash + jq + python3 on every route, as before.
