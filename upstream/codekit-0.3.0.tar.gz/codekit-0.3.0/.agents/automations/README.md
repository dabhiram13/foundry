# Codex Automations

These files are prompt specs for Codex automations.

Recommended initial setup:
- `daily-ops-summary.md`: daily or weekday morning digest
- `nightly-heal.md`: nightly bounded remediation pass

Recommended execution model:
- monitor automation creates context and routing
- heal automation only runs when there is enough signal and bounded scope

Recommended integrations:
- Linear for ownership and backlog
- GitHub for branch/PR state
- Vercel for deployment/build/runtime status
- Sentry for production incident signal
- Gmail/email for digests or escalation
