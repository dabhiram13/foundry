# Daily Ops Summary Automation

Use this as a Codex automation prompt for a daily operating digest.

## Suggested schedule

Weekdays in the morning, Europe/Amsterdam time.

## Prompt

Review the current project state and produce an operating summary for the team.

Use Linear, GitHub, Vercel, Sentry, and any local reports under `dev/reports/` that are available.

Objectives:
- Identify critical, high, and medium items
- Call out changes since the last run
- Highlight deploy failures, runtime failures, CI problems, and urgent backlog blockers
- Create or update Linear issues for actionable items when that adds value
- Keep the output concise and decision-oriented

Rules:
- Do not make code changes
- Do not trigger fixes directly unless there is a clearly bounded critical issue and the workflow explicitly allows that
- Prefer deduplicated issues over creating new noise
- Include links to the relevant Linear issues, PRs, or deployments when available

Output sections:
- Critical now
- Needs attention today
- Fixed or cleared
- Waiting or blocked

If nothing important changed, say that directly and briefly.
