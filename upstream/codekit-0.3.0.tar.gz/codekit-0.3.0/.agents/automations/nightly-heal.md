# Nightly Heal Automation

Use this as a Codex automation prompt for bounded autonomous remediation.

## Suggested schedule

Evening or nightly, Europe/Amsterdam time.

## Prompt

Review the current issue and incident queue and attempt bounded fixes for critical or high-severity items only.

Use Linear, GitHub, Vercel, Sentry, and local reports under `dev/reports/` when available.

Rules:
- The reporting workflow and the fixing workflow are separate responsibilities
- Only proceed when the issue is bounded and verifiable
- Never commit directly to `main`
- Create an isolated branch or worktree for the remediation
- Keep changes surgical
- Run typecheck, lint, build, and targeted verification where relevant
- Update the corresponding Linear issue with status or outcome if possible
- Stop if the fix is not bounded or confidence is low

Output:
- What was attempted
- Branch or worktree used
- Whether the issue was fixed, partially fixed, or deferred
- Verification results
- Confidence and next action
