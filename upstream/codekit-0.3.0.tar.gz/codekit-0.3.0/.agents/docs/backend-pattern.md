# Backend Pattern

Opinionated default for this kit:

- Keep the backend boring.
- Supabase owns auth, data, RLS, realtime.
- oRPC owns typed server contracts.
- Stripe side effects happen through Supabase Edge Functions.
- Inngest handles background work, fan-out, and retries.

Judgment: `.agents/philosophy/trust-boundaries.md`, `entitlement.md`, `data-flow.md`.

## Defaults

- Start from `db-schema.md` before inventing tables.
- Every table gets RLS.
- Never put service-role logic in client code.
- Prefer one clear oRPC procedure over leaky route sprawl.
- Put validation at the boundary with Zod.
- If the flow has retries, idempotency, or async fan-out, move it to Inngest.

## Smells

- Business logic split across client hooks and SQL ad hoc.
- Procedures that return inconsistent shapes.
- New tables without policy thinking.
- Webhook logic mixed directly into UI-oriented code.
- Background work handled by request/response code.

## Read Next

- `docs/patterns/backend/INDEX.md`
- `docs/patterns/backend/orpc.md`
- `docs/patterns/backend/idempotency.md`
- `docs/patterns/backend/inngest.md`
- `docs/supabase/INDEX.md`
