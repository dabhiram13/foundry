#!/usr/bin/env bash
set -euo pipefail

# codex-monitor-run.sh — Wrapper for scheduled Codex tasks
# Adds retry with backoff, structured status tracking, optional webhook delivery.
#
# Usage:
#   codex-monitor-run.sh <check-name> <prompt> [--notify <target>]

CHECK="${1:?Usage: codex-monitor-run.sh <check> <prompt> [--notify <url>]}"
PROMPT="${2:?Usage: codex-monitor-run.sh <check> <prompt> [--notify <url>]}"
WEBHOOK=""
if [ "${3:-}" = "--notify" ] && [ -n "${4:-}" ]; then
  WEBHOOK="$4"
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
CODEX_BIN="$(which codex)"
REPORT_DIR="$PROJECT_DIR/dev/reports/$CHECK"
STATUS_FILE="$PROJECT_DIR/dev/reports/status.json"
LOG_FILE="$REPORT_DIR/cron.log"
LAST_MESSAGE_FILE="$REPORT_DIR/last-message.txt"

mkdir -p "$REPORT_DIR"

BACKOFF=(30 60 300)
MAX_ATTEMPTS=3
ATTEMPT=0
EXIT_CODE=1
OUTPUT=""

while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
  ATTEMPT=$((ATTEMPT + 1))

  OUTPUT=$(cd "$PROJECT_DIR" && "$CODEX_BIN" exec "$PROMPT" \
    --cd "$PROJECT_DIR" \
    --model gpt-5.4 \
    --sandbox danger-full-access \
    --skip-git-repo-check \
    --output-last-message "$LAST_MESSAGE_FILE" \
    --json 2>&1) && EXIT_CODE=0 || EXIT_CODE=$?

  [ $EXIT_CODE -eq 0 ] && break

  if echo "$OUTPUT" | grep -qiE '429|rate.limit|overload|timeout|timed out|5[0-9]{2}|network|connection'; then
    DELAY_IDX=$((ATTEMPT - 1))
    DELAY=${BACKOFF[$DELAY_IDX]:-300}
    echo "[$(date -Iseconds)] $CHECK: attempt $ATTEMPT/$MAX_ATTEMPTS failed (transient), retrying in ${DELAY}s" >> "$LOG_FILE"
    sleep "$DELAY"
  else
    echo "[$(date -Iseconds)] $CHECK: attempt $ATTEMPT/$MAX_ATTEMPTS failed (permanent), aborting" >> "$LOG_FILE"
    break
  fi
done

echo "[$(date -Iseconds)] $CHECK: finished attempt=$ATTEMPT exit=$EXIT_CODE" >> "$LOG_FILE"
echo "$OUTPUT" >> "$LOG_FILE"
echo "---" >> "$LOG_FILE"

touch "$STATUS_FILE"
[ -s "$STATUS_FILE" ] || echo '{}' > "$STATUS_FILE"

STATUS=$([ $EXIT_CODE -eq 0 ] && echo "ok" || echo "error")
LAST_ERROR=""
[ $EXIT_CODE -ne 0 ] && LAST_ERROR=$(echo "$OUTPUT" | tail -1 | head -c 500)
SUMMARY=$(head -c 1000 "$LAST_MESSAGE_FILE" 2>/dev/null || echo "")

TMP_STATUS=$(mktemp)
jq --arg check "$CHECK" \
   --arg status "$STATUS" \
   --arg lastRun "$(date -Iseconds)" \
   --argjson attempts "$ATTEMPT" \
   --arg error "$LAST_ERROR" \
   --arg summary "$SUMMARY" \
   '.[$check] = {
      status: $status,
      lastRunAt: $lastRun,
      attempts: $attempts,
      lastError: $error,
      lastSummary: $summary,
      consecutiveErrors: (
        if $status == "ok" then 0
        else ((.[$check].consecutiveErrors // 0) + 1)
        end
      )
    }' "$STATUS_FILE" > "$TMP_STATUS" && mv "$TMP_STATUS" "$STATUS_FILE"

if [ -n "$WEBHOOK" ]; then
  ICON=$([ "$STATUS" = "ok" ] && echo "OK" || echo "ALERT")

  if [[ "$WEBHOOK" == *hooks.slack.com* ]] || [[ "$WEBHOOK" == *discord.com/api/webhooks* ]]; then
    PAYLOAD=$(jq -n \
      --arg text "${ICON} ${CHECK} — ${STATUS} | attempts: ${ATTEMPT}
${SUMMARY}" \
      '{text: $text, content: $text}')
    curl -s -X POST "$WEBHOOK" \
      -H "Content-Type: application/json" \
      -d "$PAYLOAD" >> "$LOG_FILE" 2>&1 || true
  else
    PAYLOAD=$(jq -n \
      --arg check "$CHECK" \
      --arg status "$STATUS" \
      --arg summary "$SUMMARY" \
      --arg time "$(date -Iseconds)" \
      --argjson attempts "$ATTEMPT" \
      '{check: $check, status: $status, summary: $summary, timestamp: $time, attempts: $attempts}')
    curl -s -X POST "$WEBHOOK" \
      -H "Content-Type: application/json" \
      -d "$PAYLOAD" >> "$LOG_FILE" 2>&1 || true
  fi
fi

exit $EXIT_CODE
