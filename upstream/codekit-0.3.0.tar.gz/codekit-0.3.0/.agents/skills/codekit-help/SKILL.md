---
name: codekit-help
description: Show all available slash commands grouped by purpose. Run this anytime you forget what's available or want a quick tour of the framework surface.
user-invocable: true
disable-model-invocation: true
---


# Help

Print the command map below, then stop. No tool calls, no file writes.

---

## Getting started

- **`$codekit-start`** — first-session intake. Runs once per project. Writes `.claude/state/project-started.json` when done.
- **`$codekit-skeleton saas`** — clone the Next.js + Supabase + Stripe starter into `webapp/` + `supabase/`.
- **`$codekit-setup <service>`** — guided credential and env-var wiring for a single service. Reads `.agents/docs/setup-links.md` for signup URLs and CLI install commands.

## Build flow

- **`$codekit-discover`** — deep product discovery for a new idea (competitors, users, tech reqs, external tools).
- **`$codekit-deep-interview`** — multi-turn interview version of `$codekit-discover` for fuzzy ideas.
- **`$codekit-mvp-spec`** — produce the MVP roadmap from discovery output.
- **`$codekit-mvp-build`** — execute the roadmap.
- **`$codekit-spec`** — spec one focused feature.
- **`$codekit-enhance`** — add or extend a single feature.
- **`$codekit-fix-issue`** — targeted bug fix.

## Specialist routers

- **`$codekit-design`** — design system, tokens, components.
- **`$codekit-landing-design`** — marketing page design.
- **`$codekit-logo`** — SVG logo iteration.
- **`$codekit-blog`** / **`$codekit-seo`** / **`$codekit-emails`** / **`$codekit-fumadocs`** — content + docs surfaces.
- **`$codekit-payments`** — Stripe wiring (products, prices, webhooks, customer portal).
- **`$codekit-analytics`** — PostHog / Umami install + event taxonomy.
- **`$codekit-sentry`** — error monitoring install + project wiring.

## Quality + shipping

- **`$codekit-audit`** — full repo audit (security + performance + dependencies + drift).
- **`$codekit-security`** / **`$codekit-pentest`** — security-only scan / real exploit validation.
- **`$codekit-performance`** — frontend + backend + DB profiling.
- **`$codekit-drift`** — pattern-drift detection across features.
- **`$codekit-heal`** — read all reports, create a branch, fix, verify, report.
- **`$codekit-monitor`** — set up recurring scheduled audits.
- **`$codekit-deploy`** — ship to Vercel. (Docker/VPS paths arrive in v0.2.)

## Infra + ops

- **`$codekit-domain`** — custom domain + DNS wiring.
- **`$codekit-rate-limit`** — rate-limit middleware + per-route tuning.
- **`$codekit-schema-sync`** — sync `db-schema.md` with current Supabase state.
- **`$codekit-trace`** — analyze agent trajectories, evolve skills.
- **`$codekit-settings`** — framework settings surface.

---

## Key file locations

- `AGENTS.md` — project rules (stack, code standards, workspace protocol)
- `.agents/docs/INDEX.md` — pattern-doc index (backend, frontend, UI, mobile)
- `.agents/docs/setup-links.md` — signup URLs + CLI install commands per service
- `docs/INDEX.md` — master docs index (stack references + built-feature docs)
- `db-schema.md` — current Supabase schema (tables, RLS, relationships)
- `dev/active/{feature}/` — in-progress work (plan, decisions, context)
- `dev/archive/{feature}/` — completed features

---

## Installing more Codex

- Not installed? `npm install -g @anthropic-ai/claude-code`
- Already here? Just type any of:
  - "build a SaaS for dog walkers"
  - "add Stripe to my existing Next app"
  - "audit my repo for security issues"

The orchestrator routes automatically. Prefer to pick the path yourself? Type `$codekit-start`.

---

## Docs

- npm package: https://www.npmjs.com/package/buildthisnow
- Source: https://github.com/ZeiProX76/codekit
