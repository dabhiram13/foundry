---
name: session-management
description: >
  Inspect Claude session history and transcript files when the user wants to resume work,
  recover context, find an old conversation, search prior decisions, inspect transcript paths,
  or grep Claude's saved `.jsonl` history. Use for "resume session", "find my old chat",
  "search transcript", "where are Claude sessions stored", "recover previous context",
  "session history", or "look in the jsonl files".
---

# Session Management

Use this skill to recover prior Claude context quickly without guessing where session data lives.

## Where Claude stores sessions

Primary path:

```bash
~/.claude/projects/<project-slug>/*.jsonl
```

Project slug pattern:

```text
/Users/you/my-app
-> -Users-you-my-app
```

Common examples:

```bash
~/.claude/projects/-Users-speedy-devv-codekit/
~/.claude/projects/-Users-speedy-devv-superclaude/
```

## What to look for

- `*.jsonl` — raw Claude conversation transcript
- user messages — lines containing `"type":"user"`
- assistant/tool output — useful for recovering decisions and commands

## Fast workflow

1. Resolve the project slug from the current repo path.
2. List the newest transcript files:

```bash
find "$HOME/.claude/projects/<slug>" -maxdepth 1 -name '*.jsonl' | sort
```

3. Search for the topic or human prompt:

```bash
rg -n '"type"\\s*:\\s*"user"|keyword|feature-name' "$HOME/.claude/projects/<slug>"
```

4. If needed, inspect a bounded window:

```bash
sed -n '1,120p' "$HOME/.claude/projects/<slug>/<session>.jsonl"
```

## Use cases

### Resume a feature

- Find the newest transcript in the current project slug.
- Search for the feature name, command name, or user wording.
- Summarize only the decisions, file references, and next steps.

### Recover a prior command flow

- Search user prompts for `/start`, `/spec`, `/mvp-build`, or a feature slug.
- Pull the last clear intent, plan, and blockers.

### Build a session summary

Extract only:

- what the user wanted
- what was changed
- what was deferred
- what the next action should be

Do not dump raw transcript text unless explicitly asked.

## Rules

- Prefer `rg` over broad reads.
- Search by user wording first, not by assistant paraphrase.
- Keep summaries short and decision-focused.
- Treat transcript files as local history, not canonical product docs.

## Related paths

- `.claude/projects/` in this repo — local project memory seed files
- `dev/active/` — current feature workspace
- `dev/archive/` — completed feature workspace
