# Autonomous Ops Workflow

This file defines the Codex-native operating model for builder-heavy SaaS work across Linear, GitHub, Vercel, Sentry, and optional email.

## Objective

Create a closed loop that:
- watches production and delivery signals
- summarizes what matters
- opens or updates Linear issues
- creates remediation branches/worktrees when justified
- separates reporting from fixing
- leaves humans with clear merge/review decisions instead of raw noise

## Roles

### 1. Monitor agent
Responsibilities:
- Collect signals
- Deduplicate incidents
- Rank by business impact
- Write a concise daily or on-demand summary
- Create/update Linear issues
- Trigger heal only for critical or high-confidence fixable items

Must not:
- Own implementation
- Mix operational summary with remediation code changes

### 2. Heal agent
Responsibilities:
- Work from a bounded issue queue
- Create a dedicated branch/worktree
- Make surgical fixes
- Run verification gates
- Report confidence and residual risk

Must not:
- Rewrite scope
- Batch unrelated work
- Merge automatically

### 3. Security review agent
Responsibilities:
- Audit recent changes and exposed risk surfaces
- Prioritize real attack paths over checklist noise
- Feed high-signal findings into monitor and heal

## Source systems

Primary:
- Linear: planning, issue tracking, ownership, backlog state
- GitHub: PRs, commit status, CI state, code review flow
- Vercel: deployment state, build logs, runtime logs

Secondary:
- Sentry: production failures
- Gmail/email: digests and urgent escalation
- PostHog or analytics: optional business-signal context

## Severity model

### Critical
- production outage
- broken billing/auth core flow
- data corruption risk
- security issue with realistic exploit path

Default action:
- create/update Linear immediately
- run heal if confidence is high enough to attempt a bounded fix
- send urgent summary

### High
- degraded core flow
- repeated runtime failure
- CI/deploy failure blocking delivery
- performance regression affecting activation or conversion

Default action:
- create/update Linear
- heal if bounded and testable
- include in same-day summary

### Medium
- non-blocking defect
- drift, docs mismatch, flaky non-core issues

Default action:
- create/update backlog item
- summary only

## Fix gate

Heal should only start when all are true:
- issue is critical or high
- likely fix scope is bounded
- branch/worktree isolation is available
- verification path exists

If any gate fails:
- do not auto-fix
- update Linear with context and recommendation

## Verification gates

Minimum:
- typecheck
- lint
- build

Contextual:
- targeted tests for touched flows
- deployment/build verification
- runtime/log re-check if relevant

## Output contract

Every monitor run should produce:
- top risks
- items fixed since last run
- items needing owner input
- Linear links
- GitHub/PR/deploy context where relevant

Every heal run should produce:
- issue addressed
- branch/worktree used
- files changed
- gates run
- verified vs unverified items
- confidence score
