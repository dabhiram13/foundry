# Digital Product Template Contract

This contract defines what the template must guarantee.

If a future workflow, page, or customization breaks this contract, it is out of spec.

## 1. Product Contract

The template is for selling digital products.

It is not for:

- SaaS dashboards
- internal tools
- consumer social apps
- logged-in workspaces as the primary experience

## 2. Route Contract

The product must be primarily public-facing.

### Required routes

- `/`
- `/docs`
- `/blog`
- `/terms`
- `/privacy`
- `/success`

### Allowed support routes

- checkout-related routes
- webhook/edge-function endpoints
- optional install/examples/compare routes

### Forbidden primary routes

- `/dashboard`
- `/app`
- `/protected`

## 3. CTA Contract

The main CTA must send users directly to checkout.

Allowed:

- `Get the framework`
- `Buy now`
- `Get access`

Disallowed as the primary CTA:

- `Create account`
- `Start free trial`
- `Book a demo`

## 4. Purchase Contract

The purchase flow must work in this order:

1. user clicks CTA
2. user checks out
3. payment succeeds
4. account is created or linked
5. access is provisioned
6. user lands on success/access page
7. email confirmation is sent

Any alternative flow must still preserve purchase-before-access.

## 5. Access Contract

The initial template must support key-based product access.

Required outcome:

- buyer receives an access key, API key, license, or equivalent entitlement
- buyer can use product access via the documented install/use flow

The contract assumes a Keygen-like or equivalent entitlement model.

## 6. Landing Page Contract

All product sites must share the same landing-page skeleton.

### The following are fixed

- section order
- CTA placement logic
- page rhythm
- design primitives
- offer structure

### The following are variable

- copy
- logo
- colors/theme values
- screenshots/media
- product proof
- testimonials
- price

## 7. Design Contract

The template must have one reusable design system.

Required:

- shared tokens
- shared components
- shared layout logic
- shared conversion UI patterns

Disallowed:

- redesigning core layout per product
- introducing a different component system per product
- changing the overall UX architecture per product

## 8. Docs Contract

Every product site must include reusable docs/tutorial infrastructure.

Required:

- docs shell
- MDX or markdown content model
- install guide pattern
- examples/tutorial pattern

The docs system should reuse the Fumadocs-style model already proven in `./`.

## 9. Blog / GEO Contract

Every product site must be content-ready.

Required:

- blog index
- blog post template
- crawlable docs
- metadata
- sitemap
- robots
- structured data

Preferred:

- answer-engine-friendly formatting
- FAQ and how-to support
- comparison content support

## 10. Legal Contract

Every product site must include templated legal coverage.

Required:

- terms
- privacy
- purchase/access language

Optional per product:

- refund policy
- license policy
- support policy

## 11. Email Contract

Every product site must support the following baseline emails:

- purchase confirmation
- access/setup email
- tutorial or onboarding follow-up

## 12. Customization Contract

Launching a new product site should require only product-level inputs.

Required product inputs:

- product name
- tagline
- target audience
- offer description
- price
- screenshots
- docs/tutorial content
- brand direction

The operator must not need to redefine:

- route structure
- conversion flow
- checkout logic
- docs architecture
- legal architecture
- SEO architecture

## 13. Workflow Contract

`.agents/` will own the template workflows.

`.claude/` must remain unchanged.

Future `.agents` workflows must therefore:

- adapt the template
- specialize the content
- preserve the contract
- avoid changing the underlying `.claude` orchestration model

## 14. Reuse Contract

The template is only valid if it enables repeated launches.

Minimum success test:

- the same structure can support at least five digital-product sites
- each site can have different branding and copy
- none of those launches require rethinking the base UX or page system

## 15. Delivery Contract

The template is complete only when it can:

1. present the offer
2. convert the buyer
3. take payment
4. provision access
5. deliver docs/tutorial entry points
6. support SEO/GEO growth

If any one of those is missing, the template is incomplete.
