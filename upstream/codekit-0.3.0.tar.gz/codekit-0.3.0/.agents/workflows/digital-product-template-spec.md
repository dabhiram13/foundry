# Digital Product Template Spec

This spec defines the first template to build on top of Build Kit.

It is not a generic SaaS app template.
It is a reusable website factory for selling digital products such as `Growth Kit`, `Code Kit`, and similar products.

## Objective

Create one high-conviction public website template that can be reused across many digital products with minimal structural change.

The template must let us launch multiple product sites fast by changing only:

- product name
- copy
- pricing details
- logo
- color/theme direction
- screenshots/media
- docs/tutorial content

Everything else should remain structurally consistent.

## Product Model

Each site sells a digital product.

Examples:

- a Claude/Codex framework
- a starter kit
- a template pack
- a guide/library/toolkit

The site is mostly public.
It exists to:

1. explain the offer
2. establish trust
3. drive checkout
4. grant access after payment
5. host docs/tutorial content
6. capture SEO/GEO demand

## Core Constraints

- No private product app area as a primary experience
- Public pages only for the main product journey
- Main CTA should go directly to checkout
- Purchase is the conversion event, not sign-up
- Account creation happens after successful purchase
- Product delivery uses key-based access and `npx` install flow
- Fumadocs-style documentation is part of the product template
- `.claude/` remains untouched
- `.agents/` becomes the specialization layer for this product factory

## Non-Goals

- No multi-tenant dashboard product
- No complex logged-in workspace
- No feature-specific private app flows
- No custom site structure per product
- No redesigning the UX architecture each time

## Template Architecture

The template has five fixed layers.

### 1. Brand Layer

Per-product customization inputs:

- product name
- category
- tagline
- logo
- color direction
- screenshot/media set

Per-product outputs:

- logo assets
- theme token values
- brand copy variables

### 2. Conversion Layer

Fixed structure:

- landing page
- pricing/offer sections
- purchase CTA
- checkout
- post-purchase account creation
- key/access delivery

This layer must remain structurally stable across products.

### 3. Content Layer

Fixed structure:

- docs/tutorial site
- blog
- SEO/GEO pages
- comparison/use-case/supporting content

This is the main acquisition and education surface.

### 4. Trust Layer

Fixed structure:

- legal pages
- refund/access policy copy
- delivery explanation
- support/contact paths
- product proof and credibility blocks

### 5. Operations Layer

Fixed structure:

- monitoring
- analytics
- email sequencing
- SEO/GEO review
- maintenance automations

## Information Architecture

Every product site should use the same top-level structure.

### Required Public Routes

- `/` — landing page
- `/docs` — product documentation/tutorials
- `/blog` — blog index
- `/blog/[slug]` — blog post
- `/terms` — terms
- `/privacy` — privacy
- `/refund-policy` or equivalent if needed
- `/success` — post-checkout success/access handoff

### Optional Public Routes

- `/compare/[slug]` — comparison pages
- `/examples` — product examples
- `/install` — install guide shortcut
- `/tutorials` — if separated from docs

### Disallowed As Primary Template Routes

- `/dashboard`
- `/app`
- `/protected`
- `/workspace`

If auth exists, it exists only to support access after purchase, not as the core site experience.

## Primary User Flow

The main flow is fixed.

1. User lands on the marketing site.
2. User understands the offer fast.
3. User clicks the top-right CTA or primary CTA.
4. User goes directly to checkout.
5. User pays.
6. System creates or links an account.
7. System grants product access/license.
8. User lands on success/access page.
9. User receives email with access details.
10. User installs or uses the product via docs and `npx` flow.

## Secondary User Flows

### SEO/GEO Content Flow

1. User lands on a blog or docs page from search/AI answers.
2. User gets value from the content.
3. User encounters product CTA in content context.
4. User enters the same checkout flow.

### Docs-Led Conversion Flow

1. User evaluates docs/tutorials first.
2. User sees examples, install flow, and proof.
3. User upgrades to purchase.

## Landing Page Template

This is the most important template artifact.

It should be created once, then adapted per product by changing copy and product assets only.

### Landing Page Invariants

- Same section order for every product unless explicitly overridden
- Same spacing rhythm and layout system
- Same CTA placement model
- Same pricing/offer presentation model
- Same social proof pattern
- Same FAQ structure
- Same footer structure

### Required Landing Sections

1. Hero
2. Proof bar or credibility strip
3. Problem
4. Solution or product explanation
5. What's included
6. Use cases / who it's for
7. Product proof or walkthrough
8. Pricing / offer
9. FAQ
10. Final CTA

### Landing Page Variables

- copy
- screenshots
- testimonials/proof
- product-specific bullets
- price
- guarantees/refund details

### Landing Page Non-Variables

- structural UX
- section sequence
- CTA behavior
- design system primitives

## Design Direction

The design system should be template-first, not product-first.

Meaning:

- one shared visual grammar
- one strong layout logic
- one consistent conversion pattern
- per-product theming applied on top

### Design Goals

- premium
- clear
- credible
- product-focused
- fast to scan
- easy to adapt

### Design Constraints

- avoid dashboard-like clutter
- avoid generic SaaS gradients without intent
- avoid rebuilding component structure per site
- optimize for conversion and reuse over novelty

## Documentation / Fumadocs Layer

The separate `build` repo already shows the desired direction: a docs-heavy product with markdown/MDX content and Fumadocs-style structure.

This template should adopt that model as a fixed content system.

### Docs Goals

- installation guides
- product tutorials
- examples
- troubleshooting
- FAQs
- product comparisons where useful

### Docs Invariants

- same docs IA across products
- same MDX-based authoring model
- same docs layout shell
- same content component system

### Docs Variables

- product-specific tutorials
- examples
- install commands
- product screenshots

## Commerce / Access Model

The commerce flow is fixed.

### Payment Rules

- primary CTA goes to checkout
- no free app sign-up before checkout
- checkout is the first serious commitment step
- support one-time purchase first
- subscription can be supported later if needed, but is not required for the initial template

### Post-Purchase Rules

- create or associate user account after payment
- generate or attach product entitlement
- deliver access details immediately
- deliver email confirmation immediately
- route user to success/access page

### Access Delivery Model

The initial spec assumes a key/license flow like the `build` product:

- user purchases product
- system provisions access
- user receives an API key or license credential
- user uses `npx` plus key to access/download/install

## Email System

Email is part of the template, not an afterthought.

### Required Emails

- purchase confirmation
- access/setup email
- abandoned checkout or follow-up sequence if implemented
- onboarding/tutorial sequence

### Email Goals

- reduce support load
- increase activation
- reinforce product value
- move users into docs and usage quickly

## SEO / GEO Layer

This template must be content-distribution-ready from day one.

### SEO Scope

- metadata
- sitemap
- robots
- structured data
- OG images
- blog architecture
- docs crawlability

### GEO / AI SEO Scope

- AI-bot-access-aware robots strategy
- answer-friendly content structure
- FAQ and how-to content
- comparison pages where useful
- citation-friendly docs/blog formatting

## Legal Layer

Required legal artifacts for every product site:

- terms
- privacy
- refund/access policy as needed
- purchase/access language

These should be templated and adapted per product, not written from scratch each time.

## Monitoring / Maintenance Layer

The template should be ready for later automation, but automation is not the first deliverable.

Template must be designed so future automations can reliably manage:

- content review
- SEO/GEO review
- monitoring summaries
- maintenance issues
- bounded fixes

## Module Inventory

The template is composed of these modules:

### Mandatory Modules

- brand/theme module
- landing page module
- checkout/payment module
- post-purchase access module
- docs module
- blog module
- legal module
- email module
- SEO/GEO module

### Optional Modules

- comparison pages
- examples gallery
- affiliate/referral pages
- advanced email lifecycle flows
- multi-product catalog

## Customization Surface

Per new product, the operator should only need to provide:

- product name
- one-line promise
- target customer
- product type
- price
- key benefits
- screenshots/assets
- brand direction
- docs/tutorial content

Everything else should come from the template.

## Workflow Program To Build Later

After this spec is accepted, `.agents/` should eventually contain workflows for:

- template foundation
- landing adaptation
- docs adaptation
- checkout/access wiring
- blog/SEO setup
- legal adaptation
- email adaptation
- brand customization

## Build Order

The template should be built in this order:

1. template contract
2. design system + brand token shell
3. landing page template
4. checkout + payment flow
5. post-purchase access flow
6. docs/tutorial template
7. blog + SEO/GEO template
8. legal template
9. email sequence template
10. monitoring/maintenance hooks

## Success Criteria

The template is successful when:

- one product site can be generated without redesigning structure
- later product sites reuse the same architecture
- conversion flow remains identical across products
- docs/blog/content system is reusable
- branding can change without structural edits
- the site can sell and deliver a digital product without requiring a private app
