# Step Prompt Standard

How to write step prompts for Build This Now build kits.
These prompts are served on the website. Users copy-paste them into Claude Code.

---

## Principles

1. **Product language, not code language** — Describe what the user experiences, not what the database stores
2. **Behavior over implementation** — "User clicks Save, sees a success toast" not "POST /api/rpc/entity.create returns { success: true }"
3. **Complete but concise** — Cover every flow and edge case. Skip table schemas, column types, API shapes.
4. **The planner translates** — Our agents figure out tables, procedures, types. The prompt describes the product.
5. **Testable by reading** — The tester agent reads "User Flows" and walks through each one with a real browser
6. **Sellable by reading** — A customer sees this prompt on our website and understands exactly what they're building

---

## Prompt Structure

Every step prompt follows this structure. All sections are mandatory unless marked optional.

```markdown
# Step {N}: {Feature Name}

## The Experience

### {Flow name}
{Describe what the user sees and does. Write it like a storyboard.
Start from where the user is. What do they see? What do they click?
What happens next? What feedback do they get?}

### {Another flow}
{Same format. One subsection per distinct user flow.}

## Business Logic

{Bullet list of rules that govern this feature.
- Who can do what (roles, plan tiers)
- Limits and constraints (max items, max length, rate limits)
- Data ownership (who sees what)
- Computed values or derived state
- Integration behavior (what external APIs do, timeouts, fallbacks)}

## Edge Cases & Error Handling

{Every edge case the feature must handle.
Format: **Trigger**: what happens → what the user sees.
- Validation errors
- API/service failures
- Permission denied
- Rate limits
- Empty states
- Concurrent actions
- Offline behavior (if relevant)}

## User Flows (test these)

{Numbered list of complete flows the tester agent will verify.
Each flow is a chain: start state → action → action → end state.
Include the happy path AND at least one error path per major flow.}

1. **{Flow name}**: {Start} → {Action} → {Action} → {Expected result}
2. **{Flow name}**: {Start} → {Action} → {Expected result}
...

## UI Notes

{Visual details that matter for the designer agent.
- Layout (two-column, stacked, slide-over, modal)
- Key components (cards, tables, forms, empty states)
- Loading states (skeleton, spinner, progress bar)
- Success/error feedback (toast, inline, redirect)
- Responsive behavior (what changes on mobile)
- Animations (if any)}

## What This Step Does NOT Include

{Explicit scope boundaries. What might seem related but is NOT
part of this step. Prevents agents from over-building.}

## Dependencies (optional)

{Only if this step requires something from a previous step.
- "Auth must be complete (Step 3)"
- "Design system tokens must exist (Step 1)"
Don't list obvious things like "npm installed".}

## External Services (optional)

{Only if this step needs an external API or service.
- Service name + what it's used for
- "OpenAI API — structured output for resume generation"
- "Stripe API — checkout session creation"
Reference the docs: "See docs/tools/{service}/ in your repo"}
```

---

## Writing Guidelines

### The Experience section

Write like you're narrating a demo video. Present tense. Second person.

**Good:**
> User clicks "New Resume" — a slide-over panel opens. They fill in
> the job title and paste their experience. They click "Generate".
> A loading state shows "AI is crafting your resume..." for 3-5 seconds.
> The resume appears as a preview card.

**Bad:**
> The system creates a new resume entity via the create procedure.
> Input is validated with secureObject schema. Response contains
> the created entity with generated fields.

### Business Logic section

State rules, not implementation. Let agents decide HOW.

**Good:**
> - Free users: max 1 resume, no PDF export
> - Resume data belongs to the user only
> - Max title: 100 chars. Max experience: 10,000 chars.

**Bad:**
> - Add `plan_limit` check in procedure using `context.claims.plan`
> - RLS policy: `auth.uid() = user_id`
> - Add CHECK constraint: `length(title) <= 100`

### Edge Cases section

Be exhaustive. Every error the user might encounter.

**Good:**
> - **AI generation fails**: Show "Generation failed, please try again"
>   with a retry button. Preserve the user's input.
> - **Empty form submission**: Validate before sending. Show inline
>   errors under each required field.

**Bad:**
> - Handle errors appropriately
> - Add validation

### User Flows section

These become the tester agent's script. Be specific enough to automate.

**Good:**
> 1. **First resume**: Empty state → Click "New Resume" → Fill title
>    "My Resume" → Paste experience → Click "Generate" → See preview
>    card → Click "Download PDF" → File downloads

**Bad:**
> 1. Test creating a resume
> 2. Test editing
> 3. Test deleting

### UI Notes section

Give the designer enough to build without a Figma file.

**Good:**
> - Resume cards: title, company, last edited date, word count badge
> - Editor: two-column on desktop (edit left, preview right),
>   stacked on mobile (edit top, preview bottom)
> - Loading: skeleton cards on list page, spinner overlay on generation
> - Empty state: illustration + "Create your first resume" + CTA button

**Bad:**
> - Use shadcn components
> - Make it look nice
> - Follow the design system

### Scope boundaries section

Prevents agents from gold-plating. Be explicit about what's NOT included.

**Good:**
> - Sharing resumes with others (future feature)
> - Multiple resume templates/themes (future)
> - Import from LinkedIn (future)
> - Real-time collaboration (not planned)

---

## How The Orchestrator Uses This Prompt

When the user pastes a step prompt into Claude Code:

```
1. Save full prompt → dev/active/{feature}/spec.md
2. Spawn planner with spec.md + doc indexes
   → Planner reads the product brief
   → Translates into technical tasks per agent
   → Writes plan.md with execution order + manifests
3. For each agent (in planner's order):
   → Gets BOTH spec.md (original) AND plan.md (their tasks)
   → Agent reads spec for context, plan for specific instructions
   → Agent reads reference files from manifest
   → Agent builds
4. Tester reads spec.md "User Flows" section
   → Walks through each flow with agent-browser
   → Takes screenshots as evidence
   → Writes regression test specs
5. Quality gate audits everything
```

Every agent has access to the original prompt. The planner adds structure but never replaces it.

---

## Step Prompt Examples By Type

### Core SaaS steps (1-5)

These are similar across all build kits. Only the branding and pricing details change.

| Step | Focus |
|------|-------|
| 1. Design System | Brand colors, typography, layout shell, dark mode |
| 2. Landing Page | Hero, features, pricing, FAQ, CTA — specific to this idea |
| 3. Auth | Login, signup, forgot password, email verification |
| 4. Onboarding | Welcome flow, preferences, first-action nudge |
| 5. Billing | Stripe checkout, plan management, portal, upgrade CTAs |

### Feature steps (6+)

These are unique to each idea. This is where the product brief matters most.

| Example idea | Feature steps |
|---|---|
| AI Resume Builder | 6. Dashboard, 7. Resume Editor + AI Generation, 8. PDF Export |
| Pet Health Tracker | 6. Pet Profiles, 7. Health Log, 8. Vet Appointment Booking |
| Invoice Automation | 6. Client Management, 7. Invoice Builder, 8. Payment Tracking |

### Deploy step (always last)

Short and procedural. Less product brief, more checklist:
- Vercel deployment config
- Environment variables in production
- Custom domain setup
- Final smoke test on production URL

---

## Quality Checklist For Prompt Authors

Before publishing a step prompt on the website:

- [ ] Can a non-technical person read this and understand what's being built?
- [ ] Does every user flow describe start state, actions, and expected result?
- [ ] Are all edge cases listed with specific error messages/behaviors?
- [ ] Are business rules stated as rules, not as code?
- [ ] Is the scope boundary clear (what's NOT included)?
- [ ] Are UI notes specific enough for a designer but not prescribing components?
- [ ] Would a customer see this and feel confident paying $59 for it?
- [ ] Does the "User Flows" section give the tester enough to verify with a real browser?
